YapYur v1.8.1 browser extension. Cross-platform on macOS, Linux, and Windows in supported browsers.

Chrome/Chromium or Edge: open extensions page, enable Developer mode, click Load unpacked, and select this extracted folder.
Firefox: open about:debugging#/runtime/this-firefox and choose Load Temporary Add-on, then select manifest.json.

Works on https://yapper.website and https://yapin.gg. Safari does not directly load this Chromium extension ZIP. See INSTALL-MAC-LINUX.md in the main package for full steps.
