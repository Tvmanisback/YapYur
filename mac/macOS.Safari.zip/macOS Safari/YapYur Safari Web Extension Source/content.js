(function () {
  'use strict';
  if (window.__YAPYUR_LOADED__) return;
  window.__YAPYUR_LOADED__ = true;

  const YM = {};
  window.YapYur = YM;
  window.YapperMod = YM;
  YM.version = '1.10.3';
  YM.packageId = 'Tvman.Unknown.YapYur';
  YM.mode = 'bookmarklet';
  YM.startedAt = Date.now();

  // ---- util ----
  const util = (YM.util = {});
  util.isObj = (v) => !!v && typeof v === 'object' && !Array.isArray(v);
  util.uid = () => Math.random().toString(36).slice(2, 10);
  util.clone = (v) => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
  util.debounce = (fn, w = 100) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), w); }; };
  util.escapeHtml = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  util.formatDateTime = (iso) => { try { return new Date(iso).toLocaleString(); } catch (_) { return String(iso || ''); } };
  util.pluralize = (n, one, many) => n + ' ' + (n === 1 ? one : many || one + 's');
  util.copyText = async (t) => { try { await navigator.clipboard.writeText(t); return true; } catch (_) { return false; } };

  const LOG = 'color:#7c3fff;font-weight:700';
  YM.log = {
    info: (...a) => console.log('%c[YapYur]', LOG, ...a),
    warn: (...a) => console.warn('%c[YapYur]', LOG, ...a),
    error: (...a) => console.error('[YapYur]', ...a),
    debug: (...a) => {},
  };

  class Emitter {
    constructor() { this.map = new Map(); }
    on(n, f) { let s = this.map.get(n); if (!s) this.map.set(n, (s = new Set())); s.add(f); return () => this.off(n, f); }
    off(n, f) { const s = this.map.get(n); if (s) s.delete(f); }
    has(n) { const s = this.map.get(n); return !!(s && s.size); }
    emit(n, ...a) { const s = this.map.get(n); if (!s) return; for (const f of [...s]) try { f(...a); } catch (e) { YM.log.error('listener', n, e); } }
  }
  YM.Events = new Emitter();
  YM.deferred = () => {
    let resolve, reject;
    const promise = new Promise((res, rej) => { resolve = res; reject = rej; });
    return { promise, resolve, reject };
  };
  YM.Emitter = Emitter;

  // ---- storage ----
  const LS = { settings: 'yapyur:settings', quickCss: 'yapyur:quickcss' };
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (_) {} };

  const BUNDLED = [{"fileName":"Arctic-Night.theme.css","name":"Arctic Night","author":"Tvman","description":"Cool dark blue-grays with icy cyan highlights.","css":"/**\n * @name Arctic Night\n * @author Tvman\n * @version 1.0.0\n * @description Cool dark blue-grays with icy cyan highlights.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #05080c;\n  --bg-side: #0a1016;\n  --bg-main: #0e141c;\n  --bg-elev: #141c26;\n  --bg-hover: #1a2430;\n  --bg-active: #222e3c;\n  --bg-input: #121a22;\n  --bg-float: #141c26;\n  --bg-side-solid: #0a1016;\n  --text: #e0eaf0;\n  --text-muted: #90a8b8;\n  --text-faint: #5e7488;\n  --border: #1e304044;\n  --accent: #00d4ff;\n  --accent-hover: #33ddff;\n  --accent-soft: #00d4ff33;\n  --on-accent: #001820;\n  --danger: #ff4757;\n  --success: #2ed573;\n  --warning: #ffa502;\n  --shadow: 0 10px 34px #00000066;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #00d4ff12;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #0e141ce6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #00000099;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #0a1016;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #2a4050;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #2a4050;\n}\n\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(0, 212, 255, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Ember.theme.css","name":"Ember","author":"Tvman","description":"Warm charcoal with orange/amber accents. Like dying fire.","css":"/**\n * @name Ember\n * @author Tvman\n * @version 1.0.0\n * @description Warm charcoal with orange/amber accents. Like dying fire.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #0c0805;\n  --bg-side: #140e08;\n  --bg-main: #1a120a;\n  --bg-elev: #22180e;\n  --bg-hover: #2c1e12;\n  --bg-active: #3a2818;\n  --bg-input: #1e160c;\n  --bg-float: #22180e;\n  --bg-side-solid: #140e08;\n  --text: #f0e8e0;\n  --text-muted: #b8a090;\n  --text-faint: #887060;\n  --border: #3a281844;\n  --accent: #ff8c00;\n  --accent-hover: #ffa533;\n  --accent-soft: #ff8c0033;\n  --on-accent: #1a0c00;\n  --danger: #ff2a2a;\n  --success: #40a02b;\n  --warning: #ff8c00;\n  --shadow: 0 10px 34px #00000066;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #ff8c0012;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #1a120ae6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #00000099;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #140e08;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #5c4030;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #5c4030;\n}\n\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(255, 140, 0, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Matrix.theme.css","name":"Matrix","author":"Tvman","description":"Pure black with classic green terminal text and accents.","css":"/**\n * @name Matrix\n * @author Tvman\n * @version 1.0.0\n * @description Pure black with classic green terminal text and accents.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #000000;\n  --bg-side: #020502;\n  --bg-main: #050805;\n  --bg-elev: #0a0f0a;\n  --bg-hover: #0f160f;\n  --bg-active: #141e14;\n  --bg-input: #080c08;\n  --bg-float: #0a0f0a;\n  --bg-side-solid: #020502;\n  --text: #00ff41;\n  --text-muted: #00cc33;\n  --text-faint: #008822;\n  --border: #00331144;\n  --accent: #00ff41;\n  --accent-hover: #33ff66;\n  --accent-soft: #00ff4133;\n  --on-accent: #000000;\n  --danger: #ff0033;\n  --success: #00ff41;\n  --warning: #ffff00;\n  --shadow: 0 10px 34px #00000088;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #00ff4112;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #050805e6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #000000aa;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #020502;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #004411;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #004411;\n}\n\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(0, 255, 65, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Emerald.theme.css","name":"Emerald","author":"Tvman","description":"Deep forest dark with rich emerald green accents.","css":"/**\n * @name Emerald\n * @author Tvman\n * @version 1.0.0\n * @description Deep forest dark with rich emerald green accents.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #040a07;\n  --bg-side: #081410;\n  --bg-main: #0c1a14;\n  --bg-elev: #12221a;\n  --bg-hover: #182c22;\n  --bg-active: #203a2c;\n  --bg-input: #101e18;\n  --bg-float: #12221a;\n  --bg-side-solid: #081410;\n  --text: #e0f0e8;\n  --text-muted: #90b8a8;\n  --text-faint: #5e8878;\n  --border: #1e3a2c44;\n  --accent: #10b981;\n  --accent-hover: #34d399;\n  --accent-soft: #10b98133;\n  --on-accent: #002214;\n  --danger: #ff2a2a;\n  --success: #10b981;\n  --warning: #f59e0b;\n  --shadow: 0 10px 34px #00000066;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #10b98112;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #0c1a14e6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #00000099;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #081410;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #2a4a3a;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #2a4a3a;\n}\n\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(16, 185, 129, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Toxic-Green.theme.css","name":"Toxic Green","author":"Tvman","description":"Dark charcoal with neon acid green accents. Cyber / hacker feel.","css":"/**\n * @name Toxic Green\n * @author Tvman\n * @version 1.0.0\n * @description Dark charcoal with neon acid green accents. Cyber / hacker feel.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #050805;\n  --bg-side: #0a100a;\n  --bg-main: #0e140e;\n  --bg-elev: #141c14;\n  --bg-hover: #1a241a;\n  --bg-active: #222e22;\n  --bg-input: #121a12;\n  --bg-float: #141c14;\n  --bg-side-solid: #0a100a;\n  --text: #e0f0e0;\n  --text-muted: #90b890;\n  --text-faint: #5e805e;\n  --border: #1e3a1e44;\n  --accent: #39ff14;\n  --accent-hover: #5cff3d;\n  --accent-soft: #39ff1433;\n  --on-accent: #001a00;\n  --danger: #ff2a2a;\n  --success: #39ff14;\n  --warning: #ffe600;\n  --shadow: 0 10px 34px #00000066;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #39ff1412;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #0e140ee6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #00000099;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #0a100a;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #2a4a2a;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #2a4a2a;\n}\n\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(57, 255, 20, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Void.theme.css","name":"Void","author":"Tvman","description":"Near-black with deep indigo accents. Clean and modern.","css":"/**\n * @name Void\n * @author Tvman\n * @version 1.0.0\n * @description Near-black with deep indigo accents. Clean and modern.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #06060c;\n  --bg-side: #0c0c14;\n  --bg-main: #101018;\n  --bg-elev: #16161f;\n  --bg-hover: #1c1c28;\n  --bg-active: #242433;\n  --bg-input: #14141e;\n  --bg-float: #16161f;\n  --bg-side-solid: #0c0c14;\n  --text: #e8e8f0;\n  --text-muted: #a0a0b8;\n  --text-faint: #6e6e88;\n  --border: #2a2a3a44;\n  --accent: #6c5ce7;\n  --accent-hover: #7f70f0;\n  --accent-soft: #6c5ce733;\n  --on-accent: #ffffff;\n  --danger: #ff4757;\n  --success: #2ed573;\n  --warning: #ffa502;\n  --shadow: 0 10px 34px #00000066;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #6c5ce712;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #101018e6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #00000099;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #0c0c14;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #3a3a50;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #3a3a50;\n}\n\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(108, 92, 231, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Blood-Red.theme.css","name":"Blood Red","author":"Tvman","description":"Deep blood-red dark theme with glowing crimson accents.","css":"/**\n * @name Blood Red\n * @author Tvman\n * @version 1.0.0\n * @description Deep blood-red dark theme with glowing crimson accents.\n */\n:root,\n:root[data-theme=\"light\"],\n:root[data-theme=\"dark\"] {\n  --bg-rail: #0a0000;\n  --bg-side: #140202;\n  --bg-main: #1a0505;\n  --bg-elev: #220808;\n  --bg-hover: #2e0a0a;\n  --bg-active: #3d0c0c;\n  --bg-input: #1f0606;\n  --bg-float: #220808;\n  --bg-side-solid: #140202;\n  --text: #f2e8e8;\n  --text-muted: #c9a0a0;\n  --text-faint: #8f6060;\n  --border: #5c101033;\n  --accent: #c41e1e;\n  --accent-hover: #e63939;\n  --accent-soft: #c41e1e33;\n  --on-accent: #ffffff;\n  --danger: #ff2a2a;\n  --success: #40a02b;\n  --warning: #df8e1d;\n  --shadow: 0 10px 34px #00000066;\n  color-scheme: dark;\n  --lightningcss-light: ;\n  --lightningcss-dark: initial;\n}\n\n/* Extra polish for hover / active states while Yapper is in dark mode */\n:root:not([data-theme=\"light\"]) .msg:hover,\n:root:not([data-theme=\"light\"]) .msg.menu-open,\n:root:not([data-theme=\"light\"]) .msg.editing {\n  background: #c41e1e12;\n}\n:root:not([data-theme=\"light\"]) .drop-overlay {\n  background: #1a0505e6;\n}\n:root:not([data-theme=\"light\"]) .overlay {\n  background: #00000099;\n}\n:root:not([data-theme=\"light\"]) .overlay.clear {\n  background: 0 0;\n}\n:root:not([data-theme=\"light\"]) .voice-view {\n  background: #140202;\n}\n:root:not([data-theme=\"light\"]) .voice-tile.screen {\n  background: #000;\n}\n:root:not([data-theme=\"light\"]) .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-side), inset 0 0 0 3px #5c3030;\n}\n:root:not([data-theme=\"light\"]) .main .status-dot.offline {\n  box-shadow: 0 0 0 3px var(--bg-main), inset 0 0 0 3px #5c3030;\n}\n\n/* \"Made by Tvman\" watermark – bottom right, tiny + transparent */\nbody::after {\n  content: \"Made by Tvman\";\n  position: fixed;\n  bottom: 10px;\n  right: 14px;\n  font-size: 11px;\n  font-weight: 500;\n  letter-spacing: 0.03em;\n  color: rgba(196, 30, 30, 0.35);\n  pointer-events: none;\n  z-index: 9999;\n  user-select: none;\n  font-family: inherit;\n}\n"},{"fileName":"Compact-YY.theme.css","name":"Compact YY","author":"YapYur","description":"Tighter message spacing only.","css":".msg{padding-top:1px;padding-bottom:1px}.msg:not(.grouped){margin-top:5px}.msg-text{line-height:1.32}"}];
  const data = util.clone(lsGet(LS.settings, {})) || {};
  data.plugins = data.plugins || {};
  data.enabledThemes = data.enabledThemes || [];
  if (data.useQuickCss === undefined) data.useQuickCss = true;
  // Wipe any previously auto-enabled plugins so nothing starts until the user opts in
  for (const k of Object.keys(data.plugins)) {
    if (data.plugins[k] && data.plugins[k].enabled && k !== '__keep') {
      /* leave user choices; only reset if first install flag missing */
    }
  }
  if (!data._userConfigured) {
    for (const k of Object.keys(data.plugins)) {
      if (data.plugins[k]) data.plugins[k].enabled = false;
    }
    data._userConfigured = true;
    lsSet(LS.settings, data);
  }

  const sBus = new Emitter();
  const getPath = (o, p) => { let c = o; for (const k of String(p).split('.')) { if (c == null) return; c = c[k]; } return c; };
  const setPath = (o, p, v) => { const ks = String(p).split('.').filter(Boolean); let c = o; for (let i = 0; i < ks.length - 1; i++) { if (!util.isObj(c[ks[i]])) c[ks[i]] = {}; c = c[ks[i]]; } c[ks[ks.length - 1]] = v; };
  YM.settings = {
    data,
    get(p, f) { const v = getPath(data, p); return v === undefined ? f : v; },
    set(p, v) {
      if (/(^|\.)(__proto__|constructor|prototype)(\.|$)/.test(p)) return;
      setPath(data, p, v); lsSet(LS.settings, data); sBus.emit('change', p, v); sBus.emit('change:' + p, v);
    },
    onChange: (fn) => sBus.on('change', fn),
    onPath: (p, fn) => sBus.on('change:' + p, fn),
    isPluginEnabled: (n) => !!(data.plugins[n] && data.plugins[n].enabled),
  };
  YM.PluginSettings = {
    create(name, defs) {
      const defaults = {};
      for (const [k, d] of Object.entries(defs || {})) defaults[k] = d.default;
      const store = new Proxy({}, {
        get(_t, k) { if (typeof k !== 'string') return; const raw = data.plugins[name] || {}; return raw[k] === undefined ? defaults[k] : raw[k]; },
        set(_t, k, v) { if (typeof k !== 'string') return false; YM.settings.set('plugins.' + name + '.' + k, v); return true; },
      });
      return {
        store, defaults, get: (k) => store[k], set: (k, v) => (store[k] = v),
        onChange(fn) {
          return YM.settings.onChange((p, v) => {
            if (p.startsWith('plugins.' + name + '.') && !p.endsWith('.enabled')) fn(p.slice(('plugins.' + name + '.').length), v);
          });
        },
      };
    },
  };

  // ---- DOM ----
  const dom = (YM.dom = {});
  dom.h = function (tag, props, ...ch) {
    const el = document.createElement(tag);
    if (props) for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class' || k === 'className') el.className = Array.isArray(v) ? v.filter(Boolean).join(' ') : v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'dataset') for (const [dk, dv] of Object.entries(v)) el.dataset[dk] = dv;
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'html') el.innerHTML = v;
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, String(v));
    }
    const add = (c) => { if (c == null || c === false) return; if (Array.isArray(c)) c.forEach(add); else el.append(c instanceof Node ? c : document.createTextNode(String(c))); };
    ch.forEach(add); return el;
  };
  const styles = new Map();
  const attach = (el) => { const h = document.head || document.documentElement; if (h) h.appendChild(el); else { const o = new MutationObserver(() => { const t = document.head || document.documentElement; if (t) { o.disconnect(); t.appendChild(el); } }); o.observe(document, { childList: true, subtree: true }); } };
  dom.css = {
    set(id, text) { let el = styles.get(id); if (!el) { el = document.createElement('style'); el.id = 'yy-style-' + id; styles.set(id, el); } el.textContent = text; if (!el.isConnected) attach(el); return el; },
    remove(id) { const el = styles.get(id); if (el) { el.remove(); styles.delete(id); } },
  };
  let toastHost = null;
  dom.toast = (msg, { type = 'info', duration = 3500 } = {}) => {
    if (!toastHost || !toastHost.isConnected) { toastHost = dom.h('div', { class: 'yy-toasts', role: 'status' }); (document.body || document.documentElement).appendChild(toastHost); }
    const el = dom.h('div', { class: 'yy-toast yy-toast-' + type }, String(msg)); toastHost.appendChild(el);
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 250); }, duration); return el;
  };
  YM.toast = dom.toast;

  const watchers = new Set(), mutateL = new Set();
  let scheduled = false, pending = [], observer = null;
  function matchDeep(node, sel, cb) {
    if (node.nodeType !== 1) return;
    if (node.matches && node.matches(sel)) cb(node);
    if (node.querySelectorAll) { const f = node.querySelectorAll(sel); for (let i = 0; i < f.length; i++) cb(f[i]); }
  }
  function flush() {
    scheduled = false; const batch = pending; pending = [];
    for (const w of watchers) for (const r of batch) for (const n of r.addedNodes) matchDeep(n, w.selector, (el) => { if (w.seen.has(el)) return; w.seen.add(el); try { w.fn(el); } catch (e) { YM.log.error(e); } });
    for (const fn of [...mutateL]) try { fn(batch); } catch (e) { YM.log.error(e); }
  }
  function ensureObs() {
    if (observer) return;
    observer = new MutationObserver((recs) => { for (let i = 0; i < recs.length; i++) pending.push(recs[i]); if (!scheduled) { scheduled = true; requestAnimationFrame(flush); } });
    const start = () => observer.observe(document.documentElement, { childList: true, subtree: true });
    if (document.documentElement) start(); else document.addEventListener('DOMContentLoaded', start, { once: true });
  }
  dom.watch = (sel, fn) => {
    ensureObs(); const w = { selector: sel, fn, seen: new WeakSet() }; watchers.add(w);
    const scan = () => document.querySelectorAll(sel).forEach((el) => { if (w.seen.has(el)) return; w.seen.add(el); try { fn(el); } catch (e) {} });
    if (document.body) scan(); else document.addEventListener('DOMContentLoaded', scan, { once: true });
    return () => watchers.delete(w);
  };
  dom.onMutate = (fn) => { ensureObs(); mutateL.add(fn); return () => mutateL.delete(fn); };

  // ---- themes ----
  const CUSTOM_THEMES_KEY = 'yapyur:customThemes';
  function loadCustomThemes() {
    try { return JSON.parse(localStorage.getItem(CUSTOM_THEMES_KEY) || '[]') || []; } catch (_) { return []; }
  }
  function saveCustomThemes(list) {
    try { localStorage.setItem(CUSTOM_THEMES_KEY, JSON.stringify(list)); } catch (_) {}
  }
  const Themes = (YM.themes = {
    list() {
      return BUNDLED.concat(loadCustomThemes()).slice().sort((a, b) => a.name.localeCompare(b.name));
    },
    read(fn) {
      const t = BUNDLED.find((x) => x.fileName === fn) || loadCustomThemes().find((x) => x.fileName === fn);
      return (t && t.css) || '';
    },
    applyEnabled() {
      const en = YM.settings.get('enabledThemes', []) || [];
      dom.css.set('themes', en.map((n) => Themes.read(n)).filter(Boolean).join('\n'));
    },
    toggle(fn, on) {
      let en = [...(YM.settings.get('enabledThemes', []) || [])];
      if (on) { if (!en.includes(fn)) en.push(fn); } else en = en.filter((x) => x !== fn);
      YM.settings.set('enabledThemes', en);
      Themes.applyEnabled();
    },
    parseCssFile(text, fileName) {
      const nameM = text.match(/@name\s+(.+)/);
      const authorM = text.match(/@author\s+(.+)/);
      const descM = text.match(/@description\s+(.+)/);
      const base = (fileName || 'imported.theme.css').replace(/[^\w.\-]+/g, '_');
      const file = base.endsWith('.css') ? base : base + '.theme.css';
      return {
        fileName: 'custom:' + file,
        name: (nameM && nameM[1].trim()) || file.replace(/\.theme\.css$/i, '').replace(/\.css$/i, ''),
        author: (authorM && authorM[1].trim()) || 'Imported',
        description: (descM && descM[1].trim()) || 'Imported from file',
        css: text,
        custom: true,
      };
    },
    importFromText(text, fileName) {
      const theme = Themes.parseCssFile(text, fileName);
      const list = loadCustomThemes().filter((t) => t.fileName !== theme.fileName);
      list.push(theme);
      saveCustomThemes(list);
      Themes.applyEnabled();
      return theme;
    },
    removeCustom(fn) {
      saveCustomThemes(loadCustomThemes().filter((t) => t.fileName !== fn));
      let en = (YM.settings.get('enabledThemes', []) || []).filter((x) => x !== fn);
      YM.settings.set('enabledThemes', en);
      Themes.applyEnabled();
    },
  });
  const QuickCss = {
    get: () => localStorage.getItem(LS.quickCss) || '',
    set(css) { localStorage.setItem(LS.quickCss, css); if (YM.settings.get('useQuickCss', true)) dom.css.set('quickcss', css); },
    apply() { if (YM.settings.get('useQuickCss', true)) dom.css.set('quickcss', QuickCss.get()); else dom.css.remove('quickcss'); },
  };



  // ---- Turbopack finder (YapCord 030-turbopack.js) ----
// Hooks Yapper's Turbopack runtime (before it loads) so we can (a) find modules by the names they export and
// (b) optionally patch module source. Works like Vencord's webpack hook, adapted to Turbopack's chunk format.
//
// Chunk format: globalThis.TURBOPACK.push([script, id, id, factory, id, factory, ...])  (or nested arrays)
// Module factory: (ctx, module, exports) => {...}; ctx.M = Map<id, factory>, ctx.c = Map<id, record>.

const T = (YM.turbo = {
  ctx: null, // module context, captured the first time any factory runs
  chunksSeen: 0,
  factoriesWrapped: 0,
  runtimeAttached: false,
  hookInstalled: false,
});
const ctxReady = YM.deferred();
T.ready = ctxReady.promise;

function setCtx(ctx) {
  if (T.ctx) return;
  T.ctx = ctx;
  ctxReady.resolve(ctx);
  YM.Events.emit('turbo:ready', ctx);
}

function idsBefore(list, i) {
  const ids = [];
  for (let j = i - 1; j >= 0; j--) {
    const v = list[j];
    if (typeof v === 'number' || (typeof v === 'string' && j > 0)) ids.unshift(v);
    else break;
  }
  return ids;
}

function wrapFactory(orig, ids) {
  const wrapped = function (ctx, mod, exp) {
    if (!T.ctx && ctx && ctx.M instanceof Map) setCtx(ctx);
    let fn = orig;
    if (YM.patches && YM.patches.active()) {
      try {
        fn = YM.patches.apply(orig, ids) || orig;
      } catch (err) {
        YM.log.error('patching module failed', ids, err);
      }
    }
    return fn.apply(this, arguments);
  };
  wrapped.__ym = true;
  wrapped.__orig = orig;
  wrapped.__ids = ids;
  T.factoriesWrapped++;
  return wrapped;
}

function wrapList(list, start) {
  for (let i = start; i < list.length; i++) {
    const item = list[i];
    if (Array.isArray(item)) wrapList(item, 0);
    else if (typeof item === 'function' && !item.__ym) list[i] = wrapFactory(item, idsBefore(list, i));
  }
}

function wrapChunk(chunk) {
  T.chunksSeen++;
  if (Array.isArray(chunk)) {
    try {
      wrapList(chunk, 1);
    } catch (err) {
      YM.log.error('could not wrap chunk', err);
    }
  }
}

function install() {
  if (T.hookInstalled) return;
  const g = globalThis;
  if (g.TURBOPACK && !Array.isArray(g.TURBOPACK) && typeof g.TURBOPACK.push === 'function') {
    // Runtime already booted (we were injected late): wrap its push and give up on seeing earlier chunks' factories
    // directly; the context is recovered from the first module instantiated afterwards.
    const real = g.TURBOPACK.push;
    g.TURBOPACK.push = function (...chunks) {
      chunks.forEach(wrapChunk);
      return real.apply(this, chunks);
    };
    T.hookInstalled = true;
    T.late = true;
    return;
  }

  // Before the runtime: provide the array the runtime expects (it must stay an Array, or the runtime bails out).
  const pre = Array.isArray(g.TURBOPACK) ? g.TURBOPACK : [];
  pre.forEach(wrapChunk);
  const origPush = Array.prototype.push;
  Object.defineProperty(pre, 'push', {
    configurable: true,
    writable: true,
    enumerable: false,
    value: function (...chunks) {
      chunks.forEach(wrapChunk);
      return origPush.apply(this, chunks);
    },
  });

  let current = pre;
  Object.defineProperty(g, 'TURBOPACK', {
    configurable: true,
    enumerable: true,
    get: () => current,
    set(v) {
      if (v && typeof v === 'object' && !Array.isArray(v) && typeof v.push === 'function') {
        // The runtime replaces the array with { push } once it has booted.
        const real = v.push;
        T.runtimeAttached = true;
        current = {
          push(...chunks) {
            chunks.forEach(wrapChunk);
            return real.apply(v, chunks);
          },
        };
      } else {
        current = v;
      }
    },
  });
  T.hookInstalled = true;
}

try {
  install();
} catch (err) {
  YM.log.error('Turbopack hook failed to install', err);
}

// ---- finder -------------------------------------------------------------------------------------
const srcCache = new Map(); // id -> factory source
const failed = new Map(); // id -> timestamp of last failed instantiation
const found = new Map(); // key -> exports

function hasKeys(ex, names) {
  if (!ex || (typeof ex !== 'object' && typeof ex !== 'function')) return false;
  try {
    for (const n of names) if (!Object.prototype.hasOwnProperty.call(ex, n)) return false;
    return true;
  } catch (_) {
    return false;
  }
}

function factorySource(id, factory) {
  let s = srcCache.get(id);
  if (s === undefined) {
    try {
      s = (factory.__orig || factory).toString();
    } catch (_) {
      s = '';
    }
    srcCache.set(id, s);
  }
  return s;
}

const Finder = (YM.finder = {
  /** Exports of an already instantiated module that has every name in `names`. */
  findLoaded(names) {
    const ctx = T.ctx;
    if (!ctx || !(ctx.c instanceof Map)) return null;
    for (const rec of ctx.c.values()) {
      if (!rec || rec.error) continue;
      const ex = rec.exports;
      if (hasKeys(ex, names)) return ex;
    }
    return null;
  },

  /** Module ids whose factory source contains every string. Searches modules that are not instantiated yet, too. */
  findIdsBySource(strings, limit = 10) {
    const ctx = T.ctx;
    if (!ctx || !(ctx.M instanceof Map)) return [];
    const out = [];
    for (const [id, factory] of ctx.M) {
      if (typeof factory !== 'function') continue;
      const src = factorySource(id, factory);
      if (strings.every((s) => src.includes(s))) {
        out.push(id);
        if (out.length >= limit) break;
      }
    }
    return out;
  },

  getSource(id) {
    const f = T.ctx && T.ctx.M.get(id);
    return f ? factorySource(id, f) : '';
  },

  require(id) {
    if (!T.ctx) throw new Error('Turbopack context not captured yet');
    return T.ctx.r(id);
  },

  /**
   * Find a module by the export names it declares. Instantiated modules are checked first; otherwise modules are
   * found by the quoted export names in their factory source and instantiated on demand.
   */
  findExports(names) {
    const key = names.join('|');
    const cached = found.get(key);
    if (cached) return cached;
    let ex = Finder.findLoaded(names);
    if (!ex && T.ctx) {
      const quoted = names.map((n) => '"' + n + '"');
      for (const id of Finder.findIdsBySource(quoted, 20)) {
        const last = failed.get(id);
        if (last && Date.now() - last < 2000) continue;
        try {
          const candidate = T.ctx.r(id);
          if (hasKeys(candidate, names)) {
            ex = candidate;
            break;
          }
        } catch (err) {
          failed.set(id, Date.now());
          YM.log.debug('could not instantiate module', id, err);
        }
      }
    }
    if (ex) found.set(key, ex);
    return ex || null;
  },

  /** Poll until the module exists. Resolves to the exports (or null after `timeout` ms). */
  waitFor(names, { timeout = 0, interval = 250 } = {}) {
    return new Promise((resolve) => {
      const t0 = Date.now();
      const tick = () => {
        let ex = null;
        try {
          ex = Finder.findExports(names);
        } catch (err) {
          YM.log.debug('finder error', err);
        }
        if (ex) return resolve(ex);
        if (timeout && Date.now() - t0 > timeout) return resolve(null);
        setTimeout(tick, interval);
      };
      tick();
    });
  },

  /** Returns a getter that finds the module once and caches it. */
  lazy(names) {
    let ex = null;
    return () => ex || (ex = Finder.findExports(names));
  },

  stats() {
    const ctx = T.ctx;
    return {
      hookInstalled: T.hookInstalled,
      runtimeAttached: T.runtimeAttached,
      ctxCaptured: !!ctx,
      chunksSeen: T.chunksSeen,
      factoriesWrapped: T.factoriesWrapped,
      factories: ctx && ctx.M ? ctx.M.size : 0,
      instantiated: ctx && ctx.c ? ctx.c.size : 0,
      lateInjection: !!T.late,
    };
  },
});


  // ---- Store (YapCord 040-store.js) ----
// Access to Yapper's own state store (a zustand-style store). Found by the names it exports.

const STORE_NAMES = ['useStore', 'setState', 'getState', 'upsertMessages', 'removeMessage'];
const ready = YM.deferred();

const Store = (YM.Store = {
  api: null,
  hook: null,
  ready: ready.promise,
  isReady: false,

  getState() {
    return Store.api ? Store.api.getState() : null;
  },
  setState(partial) {
    if (!Store.api) throw new Error('Yapper store is not ready yet');
    return Store.api.setState(partial);
  },
  subscribe(fn) {
    if (!Store.hook) throw new Error('Yapper store is not ready yet');
    return Store.hook.subscribe(fn);
  },

  me() {
    const s = Store.getState();
    return s && s.userId ? s.profiles[s.userId] || null : null;
  },
  myId() {
    const s = Store.getState();
    return s ? s.userId : null;
  },
  profile(id) {
    const s = Store.getState();
    return s ? s.profiles[id] || null : null;
  },
  channel(id) {
    const s = Store.getState();
    return s ? s.channels[id] || null : null;
  },
  /** DMs and group chats have no server. */
  isDmChannel(channelId) {
    const c = Store.channel(channelId);
    return !!c && !c.server_id;
  },
  activeChannelId() {
    const s = Store.getState();
    return s ? s.activeChannelId : null;
  },
  messages(channelId) {
    const s = Store.getState();
    return (s && s.messages[channelId]) || [];
  },
  /** Look a message up by id: the open channel first, then everything else that is loaded. */
  findMessage(id) {
    const s = Store.getState();
    if (!s || !id) return null;
    const active = s.messages[s.activeChannelId];
    if (active) {
      const m = active.find((x) => x.id === id);
      if (m) return m;
    }
    for (const list of Object.values(s.messages)) {
      if (!Array.isArray(list)) continue;
      const m = list.find((x) => x.id === id);
      if (m) return m;
    }
    return (s.extraMessages && s.extraMessages[id]) || null;
  },
  displayName(userId) {
    const p = Store.profile(userId);
    return p ? p.display_name || p.username || 'Unknown' : 'Unknown';
  },
  /** Yapper's chat actions module: markRead, sendMessage, editMessage, deleteMessage, openDmWith, ... (null if not found). */
  live() {
    return YM.finder.findExports(['markRead', 'sendMessage']) || YM.finder.findExports(['markRead', 'markServerRead']) || YM.finder.findExports(['markRead']);
  },
  /** Open Yapper's settings modal (same as the gear button). `tab` is one of Yapper's own tab ids, e.g. "profile". */
  openSettings(tab) {
    Store.setState({ settingsAt: tab || 'open' });
  },
  closeSettings() {
    Store.setState({ settingsAt: null });
  },
});

(async () => {
  const api = await YM.finder.waitFor(STORE_NAMES, { interval: 200 });
  Store.api = api;
  Store.hook = api.useStore;
  Store.isReady = true;
  try {
    Store.hook.subscribe((state, prev) => YM.Events.emit('store:change', state, prev));
  } catch (err) {
    YM.log.error('could not subscribe to the Yapper store', err);
  }
  YM.log.info('Yapper store found');
  ready.resolve(api);
  YM.Events.emit('store:ready', api);
})();


  // folders stub (BetterFolders may enhance later)
  if (!YM.folders) YM.folders = { list: () => [], folderOfServer: () => null, onChange: () => () => {} };

  // ---- messages API (YapCord-compatible) ----
  const decorators = new Set();
  const lastMessage = new WeakMap();
  const SELECTOR = '.msg[data-message-id]';
  function infoFor(el) {
    const id = el.getAttribute('data-message-id');
    return {
      el, id,
      message: YM.Store.isReady ? YM.Store.findMessage(id) : null,
      body: el.querySelector(':scope > .msg-body'),
      textEl: el.querySelector(':scope > .msg-body > .msg-text'),
    };
  }
  function runOn(el, only) {
    const info = infoFor(el);
    if (!info.id) return;
    lastMessage.set(el, info.message);
    for (const fn of only ? [only] : decorators) {
      try { fn(info); } catch (err) { YM.log.error('decorator', err); }
    }
  }
  dom.onMutate((batch) => {
    if (!decorators.size) return;
    const els = new Set();
    for (const rec of batch) {
      const t = rec.target && (rec.target.nodeType === 1 ? rec.target : rec.target.parentElement);
      const row = t && t.closest ? t.closest(SELECTOR) : null;
      if (row) els.add(row);
      for (const n of rec.addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.matches && n.matches(SELECTOR)) els.add(n);
        else if (n.querySelectorAll) n.querySelectorAll(SELECTOR).forEach((e) => els.add(e));
      }
    }
    els.forEach((el) => runOn(el));
  });
  YM.Events.on('store:change', (state, prev) => {
    if (!decorators.size || !prev || state.messages === prev.messages) return;
    requestAnimationFrame(() => {
      document.querySelectorAll(SELECTOR).forEach((el) => {
        const id = el.getAttribute('data-message-id');
        const msg = YM.Store.findMessage(id);
        if (lastMessage.get(el) !== msg) runOn(el);
      });
    });
  });
  YM.messages = {
    selector: SELECTOR,
    decorate(fn) { decorators.add(fn); document.querySelectorAll(SELECTOR).forEach((el) => runOn(el, fn)); return () => decorators.delete(fn); },
    refresh() { document.querySelectorAll(SELECTOR).forEach((el) => runOn(el)); },
    info: infoFor,
  };

  // ---- plugin system: LIVE start/stop when toggled ----
  const registry = new Map(), running = new Map();
  YM.definePlugin = function (def) {
    if (!def || !def.name) return null;
    def.tags = def.tags || [];
    def.authors = def.authors || ['YapYur'];
    def.settings = YM.PluginSettings.create(def.name, def.options || {});
    registry.set(def.name, def);
    // Never auto-enable: only create settings entry as disabled
    if (!data.plugins[def.name]) {
      YM.settings.set('plugins.' + def.name, { enabled: false });
    }
    return def;
  };
  function makeCtx(name, def) {
    const cleanups = [];
    return {
      settings: def.settings,
      log: { info: (...a) => YM.log.info('[' + name + ']', ...a), warn: (...a) => YM.log.warn('[' + name + ']', ...a), error: (...a) => YM.log.error('[' + name + ']', ...a) },
      css(t) { dom.css.set('plugin-' + name, t); cleanups.push(() => dom.css.remove('plugin-' + name)); },
      watch(s, f) { const o = dom.watch(s, f); cleanups.push(o); return o; },
      on(e, f) { const o = YM.Events.on(e, f); cleanups.push(o); return o; },
      onMutate(f) { const o = dom.onMutate(f); cleanups.push(o); return o; },
      interval(f, ms) { const id = setInterval(f, ms); cleanups.push(() => clearInterval(id)); return id; },
      cleanup(f) { if (typeof f === 'function') cleanups.push(f); },
      _cleanups: cleanups,
    };
  }
  YM.plugins = {
    list: () => [...registry.values()],
    get: (n) => registry.get(n),
    isEnabled: (n) => YM.settings.isPluginEnabled(n),
    isRunning: (n) => running.has(n),
    start(name) {
      if (running.has(name)) return;
      const def = registry.get(name);
      if (!def || typeof def.start !== 'function') return;
      const ctx = makeCtx(name, def);
      try {
        const r = def.start(ctx);
        if (r && typeof r.then === 'function') r.catch((e) => YM.log.error('async start', name, e));
        running.set(name, ctx);
        YM.log.info('started', name);
        YM.Events.emit('plugin:state', name, true);
      } catch (e) {
        YM.log.error('start failed', name, e);
        ctx._cleanups.forEach((f) => { try { f(); } catch (_) {} });
      }
    },
    stop(name) {
      const ctx = running.get(name);
      if (!ctx) return;
      running.delete(name);
      ctx._cleanups.forEach((f) => { try { f(); } catch (_) {} });
      dom.css.remove('plugin-' + name);
      YM.log.info('stopped', name);
      YM.Events.emit('plugin:state', name, false);
    },
    // LIVE enable: save + start/stop immediately so plugins actually work
    setEnabled(name, enabled) {
      YM.settings.set('plugins.' + name + '.enabled', !!enabled);
      if (enabled) YM.plugins.start(name);
      else YM.plugins.stop(name);
    },
    startEnabled() {
      for (const name of registry.keys()) if (YM.plugins.isEnabled(name)) YM.plugins.start(name);
    },
  };

  // net stub for folders plugin dependency in BF (optional)
  YM.net = { onFetch: () => () => {} };


  
  

  // ---- MessageLogger (YapCord plugins/MessageLogger.js) ----
// MessageLogger (port of Vencord's plugin): keeps deleted messages visible and shows the history of edited messages.
// The log lives in memory only (like Vencord): it is cleared when the page reloads.
//
// How it works on Yapper:
//  - edits: diff of the store's message lists (a message whose `edited_at` changed and whose `content` differs)
//  - deletes: Yapper dispatches `yapper:message-removed` after removing a message; the previous store state has
//    the message, so we put a copy back (flagged __ymDeleted) with upsertMessages, which sorts it into place.

(function () {
  const MAX_EDITS = 500;
  const MAX_GHOSTS = 300;

  function parseList(str) {
    return new Set(String(str || '').split(/[\s,;]+/).filter(Boolean));
  }

  function isBotMessage(msg, profile) {
    if (msg.webhook) return true;
    if (!profile) return false;
    return !!(profile.is_bot || profile.bot || (Array.isArray(profile.badges) && profile.badges.includes('bot')));
  }

  const state = { edits: new Map(), ghosts: new Map() };

  const plugin = YM.definePlugin({
    name: 'MessageLogger',
    description: 'Keeps deleted messages on screen and shows what edited messages said before. Cleared when you reload.',
    authors: ['Vencord (ported to Yapper)'],
    tags: ['Chat', 'Utility'],
    options: {
      logDeletes: { type: 'boolean', default: true, description: 'Keep deleted messages visible (marked as deleted)' },
      logEdits: { type: 'boolean', default: true, description: 'Show earlier versions of edited messages' },
      deleteStyle: {
        type: 'select',
        default: 'text',
        description: 'How deleted messages are marked',
        options: [
          { label: 'Red text', value: 'text' },
          { label: 'Red overlay', value: 'overlay' },
        ],
      },
      ignoreSelf: { type: 'boolean', default: false, description: "Don't log my own messages" },
      ignoreBots: { type: 'boolean', default: false, description: "Don't log bots and webhooks" },
      ignoreUsers: { type: 'string', default: '', description: 'User IDs to ignore (comma separated)' },
      ignoreChannels: { type: 'string', default: '', description: 'Channel IDs to ignore (comma separated)' },
      log: {
        type: 'custom',
        render(container) {
          const h = YM.dom.h;
          const info = h('span', { class: 'ym-hint' });
          const update = () => {
            info.textContent = `${YM.util.pluralize(state.ghosts.size, 'deleted message')}, ${YM.util.pluralize(state.edits.size, 'edited message')} logged`;
          };
          update();
          container.append(
            info,
            h('button', {
              class: 'ym-btn ym-btn-small',
              onClick: () => {
                if (plugin.api) plugin.api.clear();
                update();
              },
            }, 'Clear log'),
          );
        },
      },
    },

    async start(ctx) {
      const S = YM.Store;
      const settings = ctx.settings.store;
      await S.ready;
      if (!YM.plugins.isRunning('MessageLogger')) return;

      const removedCandidates = new Map(); // id -> message as it was before the removal

      function ignored(msg) {
        if (!msg) return true;
        if (settings.ignoreSelf && msg.author_id === S.myId()) return true;
        if (settings.ignoreBots && isBotMessage(msg, S.profile(msg.author_id))) return true;
        if (parseList(settings.ignoreUsers).has(msg.author_id)) return true;
        if (parseList(settings.ignoreChannels).has(msg.channel_id)) return true;
        return false;
      }

      function applyStyleClass() {
        document.documentElement.classList.toggle('ym-ml-overlay', settings.deleteStyle === 'overlay');
        document.documentElement.classList.toggle('ym-ml-text', settings.deleteStyle !== 'overlay');
      }
      applyStyleClass();
      ctx.cleanup(() => document.documentElement.classList.remove('ym-ml-overlay', 'ym-ml-text'));
      ctx.cleanup(ctx.settings.onChange((key) => {
        if (key === 'deleteStyle') applyStyleClass();
        YM.messages.refresh();
      }));

      // ---- store diff: edits + removal candidates --------------------------------------------
      ctx.on('store:change', (next, prev) => {
        if (next.messages === prev.messages) return;
        for (const channelId of Object.keys(next.messages)) {
          const a = prev.messages[channelId];
          const b = next.messages[channelId];
          if (a === b || !a || !b) continue;
          const before = new Map();
          for (const m of a) before.set(m.id, m);
          const stillThere = new Set();
          for (const m of b) {
            stillThere.add(m.id);
            const old = before.get(m.id);
            if (
              old && settings.logEdits && !old.__ymDeleted && typeof old.content === 'string' && typeof m.content === 'string' &&
              m.content !== old.content && m.edited_at && m.edited_at !== old.edited_at && !ignored(old)
            ) {
              const list = state.edits.get(m.id) || [];
              if (!list.length || list[list.length - 1].content !== old.content) {
                list.push({ content: old.content, at: m.edited_at });
                state.edits.set(m.id, list);
                if (state.edits.size > MAX_EDITS) state.edits.delete(state.edits.keys().next().value);
              }
            }
          }
          if (settings.logDeletes && a.length > b.length) {
            for (const m of a) {
              if (!stillThere.has(m.id) && !m.__ymDeleted && !m.pending && !m.failed) removedCandidates.set(m.id, m);
            }
            if (removedCandidates.size > 200) removedCandidates.delete(removedCandidates.keys().next().value);
          }
        }
      });

      // ---- Yapper confirms a deletion -----------------------------------------------------------
      function onRemoved(ev) {
        const id = ev && ev.detail;
        const msg = removedCandidates.get(id);
        removedCandidates.delete(id);
        if (!msg || !settings.logDeletes || ignored(msg)) return;
        const ghost = { ...msg, __ymDeleted: true, __ymDeletedAt: new Date().toISOString() };
        delete ghost.pending;
        delete ghost.failed;
        state.ghosts.set(id, ghost);
        if (state.ghosts.size > MAX_GHOSTS) state.ghosts.delete(state.ghosts.keys().next().value);
        setTimeout(() => restore(ghost), 0); // after Yapper's own handler has finished
      }
      window.addEventListener('yapper:message-removed', onRemoved);
      ctx.cleanup(() => window.removeEventListener('yapper:message-removed', onRemoved));

      function restore(ghost) {
        try {
          S.api.upsertMessages(ghost.channel_id, [ghost]);
        } catch (err) {
          ctx.log.warn('could not restore deleted message', err);
        }
      }

      // A reload/resync of a channel drops our copies again: put them back.
      //
      // Yapper's own message-fetch merges (loading older history, reconnecting, or just a periodic refresh of the
      // visible window) rebuild a channel's message array from what the server actually has, which never includes
      // our client-only ghosts - anything client-side that falls inside the freshly-fetched range, ours included,
      // is left out. This used to only restore a dropped ghost when it was still "inside the loaded window" (not
      // older than the channel's current oldest loaded message), on the idea that putting an out-of-window ghost
      // back would look wrong. In practice that guard is exactly what made the bug intermittent: the busier the
      // channel, the more likely a routine resync's own refetched window starts later than a just-deleted message,
      // so the very same ghost that stays put after a quiet resync quietly fails this check - and vanishes for
      // good - after a livelier one. Vencord's own version (which this is a port of) has no such window limit: a
      // deleted message stays until the plugin says otherwise, not until the server's pagination happens to agree.
      // So any tracked ghost missing from its (loaded) channel gets put back, regardless of where the window sits.
      let ensureQueued = false;
      ctx.on('store:change', (next, prev) => {
        if (next.messages === prev.messages || !state.ghosts.size || ensureQueued) return;
        ensureQueued = true;
        setTimeout(() => {
          ensureQueued = false;
          const st = S.getState();
          for (const g of state.ghosts.values()) {
            const list = st.messages[g.channel_id];
            if (list && list.length && !list.some((m) => m.id === g.id)) restore(g);
          }
        }, 120);
      });

      // ---- decoration ----------------------------------------------------------------------
      const h = YM.dom.h;
      ctx.cleanup(YM.messages.decorate(({ el, id, body, textEl }) => {
        if (!body) return;
        const msg = S.findMessage(id);
        const isGhost = !!(msg && msg.__ymDeleted) || state.ghosts.has(id);
        const mark = el.querySelector(':scope > .ym-ghost-mark');
        if (isGhost && !mark) el.append(h('span', { class: 'ym-ghost-mark', hidden: true }));
        else if (!isGhost && mark) mark.remove();

        const tag = body.querySelector(':scope > .ym-ml-tag');
        if (isGhost && !tag) {
          body.append(h('div', { class: 'ym-ml-tag' },
            h('span', {}, 'Deleted'),
            h('button', {
              class: 'ym-link',
              title: 'Remove this message from the log',
              onClick: (e) => {
                e.stopPropagation();
                state.ghosts.delete(id);
                try { S.api.removeMessage(id); } catch (_) { /* already gone */ }
              },
            }, 'remove from log')));
        } else if (!isGhost && tag) tag.remove();

        const edits = settings.logEdits ? state.edits.get(id) : null;
        const box = body.querySelector(':scope > .ym-ml-edits');
        if (!edits || !edits.length) {
          if (box) box.remove();
          return;
        }
        if (box && box.dataset.count === String(edits.length)) return;
        const fresh = h('div', { class: 'ym-ml-edits', dataset: { count: edits.length } },
          edits.map((e) => h('div', { class: 'ym-ml-edit', title: 'Edited ' + YM.util.formatDateTime(e.at) }, e.content)));
        if (box) box.replaceWith(fresh);
        else if (textEl && textEl.parentNode === body) textEl.after(fresh);
        else body.append(fresh);
      }));

      plugin.api = {
        clear() {
          for (const id of [...state.ghosts.keys()]) {
            try { S.api.removeMessage(id); } catch (_) { /* ignore */ }
          }
          state.ghosts.clear();
          state.edits.clear();
          YM.messages.refresh();
        },
      };
      ctx.cleanup(() => {
        document.querySelectorAll('.ym-ghost-mark,.ym-ml-tag,.ym-ml-edits').forEach((n) => n.remove());
        plugin.api = null;
      });

      ctx.css(`
.msg:has(> .ym-ghost-mark) .msg-actions{display:none!important}
.ym-ml-text .msg:has(> .ym-ghost-mark) .msg-text,.ym-ml-text .msg:has(> .ym-ghost-mark) .msg-text *{color:var(--danger)!important}
.ym-ml-overlay .msg:has(> .ym-ghost-mark){background:color-mix(in srgb,var(--danger) 14%,transparent)!important;box-shadow:inset 3px 0 0 var(--danger)}
.ym-ml-tag{margin-top:2px;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--danger);display:flex;gap:8px;align-items:center}
.ym-ml-tag .ym-link{all:unset;cursor:pointer;font-weight:500;text-transform:none;letter-spacing:0;color:var(--text-muted);text-decoration:underline}
.ym-ml-tag .ym-link:hover{color:var(--text)}
.ym-ml-edits{margin-top:2px;display:flex;flex-direction:column;gap:1px}
.ym-ml-edit{font-size:13px;color:var(--text-faint,#6e6f7b);white-space:pre-wrap;overflow-wrap:anywhere;opacity:.9}
.ym-ml-edit:before{content:"\\21AA  "}
`);
      YM.messages.refresh();
    },
  });
})();


// ---- BetterFolders (YapCord script, adapted) ----
// BetterFolders (port): folder improvements for the server list.
//  - a dedicated sidebar with the servers of the open folder(s), so the main list stays short
//  - close other folders when opening one / when picking a server outside folders / when pressing the home button
//  - open a server's folder automatically (forceOpen), or close it again after picking a server in it
//
// Yapper renders an open folder inline in `nav.rail` (`.rail-folder-open`). The sidebar mirrors those servers and
// forwards clicks to the real buttons, so Yapper's own navigation, unread badges and menus keep working.

(function () {
  function rail() {
    return document.querySelector('nav.rail');
  }

  function openFolderButtons() {
    const r = rail();
    return r ? [...r.querySelectorAll('button.rail-folder.open')] : [];
  }

  let internalClick = false;
  function click(el) {
    internalClick = true;
    try {
      el.click();
    } finally {
      internalClick = false;
    }
  }

  function closeFolders(except) {
    for (const b of openFolderButtons()) {
      const row = b.closest('[data-rail-row]');
      if (except && row && row.dataset.railRow === except) continue;
      click(b);
    }
  }

  YM.definePlugin({
    name: 'BetterFolders',
    description: 'Shows the servers of an open folder in a dedicated sidebar and adds folder related improvements.',
    authors: ['Vencord (ported to Yapper)'],
    tags: ['Servers', 'Appearance'],
    api: { closeFolders },
    options: {
      sidebar: { type: 'boolean', default: true, description: 'Display servers from the open folder(s) on a dedicated sidebar' },
      sidebarAnim: { type: 'boolean', default: true, description: 'Animate opening the folder sidebar' },
      keepIcons: { type: 'boolean', default: false, description: 'Keep showing the folder servers in the main list too' },
      showFolderIcon: {
        type: 'select',
        default: 'always',
        description: 'Show the folder icon above its servers in the sidebar',
        options: [
          { label: 'Never', value: 'never' },
          { label: 'Always', value: 'always' },
          { label: 'When more than one folder is open', value: 'multiple' },
        ],
      },
      closeOthers: { type: 'boolean', default: false, description: 'Close other folders when opening a folder' },
      closeAllFolders: { type: 'boolean', default: false, description: 'Close all folders when selecting a server that is not in a folder' },
      closeAllHomeButton: { type: 'boolean', default: false, description: 'Close all folders when clicking the home (direct messages) button' },
      closeServerFolder: { type: 'boolean', default: false, description: 'Close the folder when selecting a server in it' },
      forceOpen: { type: 'boolean', default: false, description: 'Open a folder when switching to a server inside it' },
    },

    start(ctx) {
      const s = ctx.settings.store;
      const h = YM.dom.h;
      let sidebar = null;
      let signature = '';

      // ---- behaviour: clicks on the rail -----------------------------------------------------
      function onClick(ev) {
        if (internalClick) return;
        const r = rail();
        const t = ev.target instanceof Element ? ev.target : null;
        if (!r || !t || !r.contains(t)) return;
        const btn = t.closest('button.rail-item');
        if (!btn) return;
        if (btn.classList.contains('rail-folder')) {
          // Opening a folder: close the others once Yapper has processed the click.
          if (s.closeOthers && !btn.classList.contains('open')) {
            const row = btn.closest('[data-rail-row]');
            const keep = row ? row.dataset.railRow : null;
            setTimeout(() => closeFolders(keep), 60);
          }
          return;
        }
        if (s.closeAllHomeButton && btn.getAttribute('title') === 'Direct messages') closeFolders();
      }
      document.addEventListener('click', onClick, true);
      ctx.cleanup(() => document.removeEventListener('click', onClick, true));

      // ---- behaviour: active server changed ---------------------------------------------------
      ctx.on('store:change', (next, prev) => {
        if (next.activeServerId === prev.activeServerId) return;
        const id = next.activeServerId;
        if (!id) return;
        const folder = YM.folders.folderOfServer(id);
        setTimeout(() => {
          const r = rail();
          if (!r) return;
          if (folder) {
            const row = r.querySelector('[data-rail-row="f:' + CSS.escape(folder.id) + '"]');
            const toggle = row && row.querySelector('button.rail-folder');
            if (!toggle) return;
            const isOpen = toggle.classList.contains('open');
            if (s.forceOpen && !isOpen) click(toggle);
            else if (s.closeServerFolder && isOpen) click(toggle);
          } else if (s.closeAllFolders) {
            closeFolders();
          }
        }, 30);
      });

      // ---- sidebar -----------------------------------------------------------------------------
      function describe() {
        const r = rail();
        if (!r || !s.sidebar) return [];
        return [...r.querySelectorAll('.rail-folder-open')].map((open) => {
          const head = open.querySelector('button.rail-folder');
          const servers = [...open.querySelectorAll('button.rail-item:not(.rail-folder)')].map((b) => {
            const wrap = b.closest('.rail-wrap');
            const badge = wrap && wrap.querySelector('.rail-badge');
            return {
              title: b.getAttribute('title') || '',
              active: b.classList.contains('active'),
              muted: b.classList.contains('muted'),
              badge: badge ? badge.textContent : '',
              dot: !!(wrap && wrap.querySelector('.rail-pill.dot')),
              html: b.innerHTML,
            };
          });
          return {
            id: open.dataset.railRow || '',
            color: open.style.getPropertyValue('--folder'),
            title: head ? head.getAttribute('title') || '' : '',
            headHtml: head ? head.innerHTML : '',
            servers,
          };
        });
      }

      function freshButton(folderId, index) {
        const r = rail();
        const open = r && [...r.querySelectorAll('.rail-folder-open')].find((o) => o.dataset.railRow === folderId);
        return open ? open.querySelectorAll('button.rail-item:not(.rail-folder)')[index] : null;
      }

      function sync() {
        const r = rail();
        if (!r) return;
        const folders = describe();
        document.documentElement.classList.toggle('ym-bf-hide', !!s.sidebar && !s.keepIcons && folders.length > 0);
        const sig = JSON.stringify([folders, s.showFolderIcon]);
        if (sig === signature && sidebar && sidebar.isConnected) return;
        signature = sig;

        if (!folders.length) {
          if (sidebar) sidebar.remove();
          sidebar = null;
          return;
        }
        const showIcon = s.showFolderIcon === 'always' || (s.showFolderIcon === 'multiple' && folders.length > 1);
        const fresh = h('div', { class: 'ym-bf-sidebar' + (s.sidebarAnim ? ' ym-bf-anim' : ''), 'aria-label': 'Folder servers' },
          folders.map((f) => h('div', { class: 'ym-bf-folder', style: f.color ? { '--folder': f.color } : undefined },
            showIcon ? h('button', {
              class: 'rail-item rail-folder open ym-bf-head',
              title: f.title,
              'aria-label': f.title,
              html: f.headHtml,
              onClick: () => {
                const r2 = rail();
                const open = r2 && [...r2.querySelectorAll('.rail-folder-open')].find((o) => o.dataset.railRow === f.id);
                const b = open && open.querySelector('button.rail-folder');
                if (b) click(b);
              },
            }) : null,
            f.servers.map((sv, i) => h('div', { class: 'rail-wrap' },
              h('span', { class: 'rail-pill' + (sv.active ? ' on' : sv.dot ? ' dot' : '') }),
              h('button', {
                class: 'rail-item' + (sv.active ? ' active' : '') + (sv.muted ? ' muted' : ''),
                title: sv.title,
                'aria-label': sv.title,
                html: sv.html,
                onClick: () => {
                  const b = freshButton(f.id, i);
                  if (b) b.click();
                },
                onContextMenu: (e) => {
                  const b = freshButton(f.id, i);
                  if (!b) return;
                  e.preventDefault();
                  b.dispatchEvent(new MouseEvent('contextmenu', { bubbles: true, cancelable: true, clientX: e.clientX, clientY: e.clientY }));
                },
              }),
              sv.badge ? h('span', { class: 'rail-badge' }, sv.badge) : null)))));
        if (sidebar && sidebar.isConnected) sidebar.replaceWith(fresh);
        else r.after(fresh);
        sidebar = fresh;
      }

      ctx.watch('nav.rail', sync);
      ctx.onMutate((batch) => {
        const r = rail();
        if (!r) return;
        // Only re-evaluate when the rail itself changed (cheap guard against unrelated chat mutations).
        for (const rec of batch) {
          const t = rec.target && (rec.target.nodeType === 1 ? rec.target : rec.target.parentElement);
          if (t && (t === r || r.contains(t))) return void sync();
        }
      });
      ctx.cleanup(ctx.settings.onChange(() => { signature = ''; sync(); }));
      ctx.cleanup(() => {
        if (sidebar) sidebar.remove();
        sidebar = null;
        document.documentElement.classList.remove('ym-bf-hide');
      });

      ctx.css(`
.ym-bf-sidebar{background:var(--bg-rail);display:flex;flex-direction:column;align-items:center;gap:14px;width:72px;flex-shrink:0;padding:12px 0;overflow-y:auto;scrollbar-width:none;border-left:1px solid var(--border)}
.ym-bf-sidebar::-webkit-scrollbar{display:none}
.ym-bf-anim{animation:ym-bf-in .2s ease}
@keyframes ym-bf-in{from{width:0;opacity:0}to{width:72px;opacity:1}}
.ym-bf-folder{display:flex;flex-direction:column;align-items:center;gap:8px;position:relative;padding:8px 0}
.ym-bf-folder:before{content:"";position:absolute;inset:0 10px;border-radius:18px;background:color-mix(in srgb,var(--folder,var(--accent)) 20%,var(--bg-elev));box-shadow:0 0 0 1px color-mix(in srgb,var(--folder,var(--accent)) 28%,transparent),0 2px 10px rgba(0,0,0,.18);pointer-events:none}
.ym-bf-folder>*{position:relative}
.ym-bf-head{color:var(--folder,var(--accent))}
.ym-bf-hide .rail-folder-open>.drag-list{display:none}
.ym-bf-hide .rail-folder-open:before{display:none}
`);
      sync();
    },
  });
})();





  // ===================== ORIGINAL YAPYUR PLUGINS (100+) =====================
  YM.definePlugin({
    name: "VoiceMicBadge",
    description: "Mic glyph next to names of people in voice.",
    authors: ['YapYur'],
    tags: ["Voice", "Appearance"],
    options: {},
    start(ctx) {

      const SVG = '<svg class="yy-vmic" width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V21h2v-3.08A7 7 0 0 0 19 11h-2z"/></svg>';
      const inVoice = (uid) => {
        const st = YM.Store.getState && YM.Store.getState();
        if (!st || !uid) return false;
        const vm = st.voiceMembers || st.voice || {};
        for (const v of Object.values(vm)) {
          const list = Array.isArray(v) ? v : (v && v.members) || [];
          if (list.some((m) => (m.userId || m.user_id || m.id) === uid)) return true;
        }
        return false;
      };
      ctx.cleanup(YM.messages.decorate(({ el, message }) => {
        const head = el.querySelector('.msg-author, .msg-head');
        if (!head) return;
        const uid = message && (message.author_id || message.authorId);
        let ic = head.querySelector('.yy-vmic');
        if (uid && inVoice(uid)) { if (!ic) head.insertAdjacentHTML('beforeend', SVG); }
        else if (ic) ic.remove();
      }));
      ctx.css('.yy-vmic{margin-left:4px;opacity:.85;vertical-align:middle;color:var(--accent)}');

    },
  });

  YM.definePlugin({
    name: "VoiceRoomTint",
    description: "Accent edge on the voice panel when visible.",
    authors: ['YapYur'],
    tags: ["Voice", "Appearance"],
    options: {},
    start(ctx) {
      ctx.css('.voice-view,.voice-panel,[class*="voice-view"]{box-shadow:inset 0 0 0 1px color-mix(in srgb,var(--accent) 35%,transparent)}');
    },
  });

  YM.definePlugin({
    name: "MuteFlash",
    description: "Red flash when clicking mute-like controls.",
    authors: ['YapYur'],
    tags: ["Voice", "Fun"],
    options: {},
    start(ctx) {

      const onClick = (e) => {
        const b = e.target.closest && e.target.closest('button[aria-label*="ute" i],button[title*="ute" i],.mute-btn');
        if (!b) return;
        b.animate([{ boxShadow: '0 0 0 0 var(--danger)' }, { boxShadow: '0 0 0 8px transparent' }], { duration: 450 });
      };
      document.addEventListener('click', onClick, true);
      ctx.cleanup(() => document.removeEventListener('click', onClick, true));

    },
  });

  YM.definePlugin({
    name: "ComposerCount",
    description: "Live character count beside the composer.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.css('.yy-ccount{font-size:11px;color:var(--text-faint);margin-left:8px;font-variant-numeric:tabular-nums}');
      ctx.watch('textarea', (ta) => {
        if (!(ta.closest('.composer') || ta.closest('[class*="composer"]'))) return;
        const tick = () => {
          let el = ta.parentElement && ta.parentElement.querySelector('.yy-ccount');
          if (!el) { el = dom.h('span', { class: 'yy-ccount' }); (ta.parentElement || ta).appendChild(el); }
          const n = ta.value.length;
          el.textContent = n ? String(n) : '';
          el.style.color = n > 1800 ? 'var(--danger)' : n > 1500 ? 'var(--warning,#f59e0b)' : 'var(--text-faint)';
        };
        ta.addEventListener('input', tick); tick();
      });

    },
  });

  YM.definePlugin({
    name: "QuoteOnDoubleClick",
    description: "Double-click a message to quote it into the composer.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      const onDbl = (e) => {
        const row = e.target.closest && e.target.closest(YM.messages.selector);
        if (!row) return;
        const author = (row.querySelector('.msg-author') || {}).textContent || 'Someone';
        const text = ((row.querySelector('.msg-text') || {}).textContent || '').trim().slice(0, 140);
        const ta = document.querySelector('.composer textarea, textarea');
        if (!ta) return;
        const snippet = '> ' + author.trim() + ': ' + text + '\n';
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(ta, snippet + ta.value);
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        ta.focus();
      };
      document.addEventListener('dblclick', onDbl, true);
      ctx.cleanup(() => document.removeEventListener('dblclick', onDbl, true));

    },
  });

  YM.definePlugin({
    name: "CopyMsgJson",
    description: "Button on messages to copy JSON payload.",
    authors: ['YapYur'],
    tags: ["Developer", "Chat"],
    options: {},
    start(ctx) {

      const ICON = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 7H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2-2v-3"/><path d="M16 3h5v5"/><path d="M10 14 21 3"/></svg>';
      ctx.cleanup(YM.messages.decorate(({ el, id, message }) => {
        const actions = el.querySelector('.msg-actions');
        if (!actions || actions.querySelector('.yy-json')) return;
        actions.prepend(dom.h('button', { type: 'button', class: 'icon-btn yy-json', title: 'Copy JSON', html: ICON,
          onClick: (e) => { e.stopPropagation(); util.copyText(JSON.stringify({ id, message }, null, 2)).then((ok) => YM.toast(ok ? 'Copied JSON' : 'Copy failed')); } }));
      }));

    },
  });

  YM.definePlugin({
    name: "CopyDeepLink",
    description: "Copy a channel+message link from the action bar.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.cleanup(YM.messages.decorate(({ el, id, message }) => {
        const actions = el.querySelector('.msg-actions');
        if (!actions || !id || actions.querySelector('.yy-deeplink')) return;
        actions.prepend(dom.h('button', { type: 'button', class: 'icon-btn yy-deeplink', title: 'Copy link',
          html: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
          onClick: (e) => {
            e.stopPropagation();
            const chan = (message && message.channel_id) || '';
            const url = location.origin + location.pathname.split('?')[0] + (chan ? '?channel=' + chan + '&message=' + id : '#' + id);
            util.copyText(url).then((ok) => YM.toast(ok ? 'Link copied' : 'Failed'));
          } }));
      }));

    },
  });

  YM.definePlugin({
    name: "FullTimeTooltip",
    description: "Hover timestamps for full local date/time.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.cleanup(YM.messages.decorate(({ el, message }) => {
        const t = el.querySelector('.msg-time, time, .timestamp');
        if (!t || t.dataset.yyFt) return;
        t.dataset.yyFt = '1';
        const iso = message && (message.created_at || message.createdAt);
        t.title = iso ? util.formatDateTime(iso) : (t.textContent || '').trim();
      }));

    },
  });

  YM.definePlugin({
    name: "ShortcutExpand",
    description: "Expands text shortcuts on Enter.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {"rules": {"type": "string", "default": "shrug=\u00af\\_(\u30c4)_/\u00af\ntableflip=(\u256f\u00b0\u25a1\u00b0)\u256f\ufe35 \u253b\u2501\u253b\nlenny=( \u0361\u00b0 \u035c\u0296 \u0361\u00b0)", "description": "find=replace per line"}},
    start(ctx) {

      const parse = () => String(ctx.settings.store.rules || '').split('\n').map((l) => {
        const i = l.indexOf('='); if (i < 1) return null; return { find: l.slice(0, i), replace: l.slice(i + 1) };
      }).filter(Boolean);
      const onKey = (e) => {
        if (e.key !== 'Enter' || e.shiftKey) return;
        const ta = e.target;
        if (!(ta instanceof HTMLTextAreaElement)) return;
        if (!(ta.closest('.composer') || ta.closest('[class*="composer"]'))) return;
        let v = ta.value; let changed = false;
        for (const r of parse()) if (r.find && v.includes(r.find)) { v = v.split(r.find).join(r.replace); changed = true; }
        if (!changed) return;
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(ta, v);
        ta.dispatchEvent(new Event('input', { bubbles: true }));
      };
      document.addEventListener('keydown', onKey, true);
      ctx.cleanup(() => document.removeEventListener('keydown', onKey, true));

    },
  });

  YM.definePlugin({
    name: "BlurLocalWords",
    description: "Blur chosen words on your screen; hover to reveal.",
    authors: ['YapYur'],
    tags: ["Privacy"],
    options: {"words": {"type": "string", "default": "", "description": "Comma-separated words"}},
    start(ctx) {

      ctx.css('.yy-blurw{filter:blur(5px);cursor:help;transition:filter .15s}.yy-blurw:hover{filter:none}');
      const apply = () => {
        const words = String(ctx.settings.store.words || '').split(/[,;\n]+/).map((w) => w.trim()).filter((w) => w.length > 1);
        if (!words.length) return;
        const re = new RegExp('(' + words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'gi');
        document.querySelectorAll('.msg-text').forEach((el) => {
          if (el.dataset.yyBw === '1') return;
          const text = el.textContent || '';
          if (!re.test(text)) return;
          re.lastIndex = 0;
          el.dataset.yyBw = '1';
          el.innerHTML = util.escapeHtml(text).replace(re, '<span class="yy-blurw">$1</span>');
        });
      };
      ctx.onMutate(util.debounce(apply, 250));
      ctx.cleanup(ctx.settings.onChange(apply));
      apply();

    },
  });

  YM.definePlugin({
    name: "PauseMediaOnHoverOut",
    description: "Videos pause when the pointer leaves them.",
    authors: ['YapYur'],
    tags: ["Performance"],
    options: {},
    start(ctx) {

      ctx.watch('.msg video, .embed video', (vid) => {
        vid.autoplay = false;
        vid.addEventListener('mouseenter', () => vid.play().catch(() => {}));
        vid.addEventListener('mouseleave', () => vid.pause());
      });

    },
  });

  YM.definePlugin({
    name: "JumpLatestFab",
    description: "Floating button to jump to newest messages.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const btn = dom.h('button', {
        type: 'button', class: 'yy-jump', title: 'Jump to latest',
        style: { position: 'fixed', right: '22px', bottom: '90px', zIndex: '40', padding: '8px 12px', borderRadius: '999px', border: '1px solid var(--border)', background: 'var(--bg-elev)', color: 'var(--text)', cursor: 'pointer', font: '12px system-ui', boxShadow: '0 4px 14px #0005', display: 'none' },
        onClick: () => {
          const sc = document.querySelector('.messages, .msg-list, [class*="message-list"]');
          if (sc) sc.scrollTo({ top: sc.scrollHeight, behavior: 'smooth' });
        },
      }, '↓ Latest');
      (document.body || document.documentElement).appendChild(btn);
      const onScroll = util.debounce(() => {
        const sc = document.querySelector('.messages, .msg-list, [class*="message-list"]');
        if (!sc) { btn.style.display = 'none'; return; }
        btn.style.display = (sc.scrollHeight - sc.scrollTop - sc.clientHeight < 90) ? 'none' : 'block';
      }, 100);
      document.addEventListener('scroll', onScroll, true);
      ctx.cleanup(() => { document.removeEventListener('scroll', onScroll, true); btn.remove(); });

    },
  });

  YM.definePlugin({
    name: "NearLimitWarn",
    description: "Shows characters remaining near the 2000 limit.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.css('.yy-left{font-size:11px;margin-left:6px}');
      ctx.watch('textarea', (ta) => {
        if (!(ta.closest('.composer') || ta.closest('[class*="composer"]'))) return;
        const tick = () => {
          let el = ta.parentElement && ta.parentElement.querySelector('.yy-left');
          const left = 2000 - ta.value.length;
          if (left > 250) { if (el) el.remove(); return; }
          if (!el) { el = dom.h('span', { class: 'yy-left' }); (ta.parentElement || ta).appendChild(el); }
          el.textContent = left + ' left';
          el.style.color = left < 0 ? 'var(--danger)' : 'var(--warning,#f59e0b)';
        };
        ta.addEventListener('input', tick); tick();
      });

    },
  });

  YM.definePlugin({
    name: "SpellOn",
    description: "Keeps spellcheck on the composer.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      ctx.watch('textarea', (ta) => {
        if (ta.closest('.composer') || ta.closest('[class*="composer"]')) ta.spellcheck = true;
      });

    },
  });

  YM.definePlugin({
    name: "HideSelfAvatar",
    description: "Hides your avatar on your own messages.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {

      ctx.cleanup(YM.messages.decorate(({ el, message }) => {
        const me = YM.Store.myId && YM.Store.myId();
        if (!me || !message || (message.author_id || message.authorId) !== me) return;
        const av = el.querySelector('.avatar, img.avatar');
        if (av) av.style.visibility = 'hidden';
      }));

    },
  });

  YM.definePlugin({
    name: "TypingSideDot",
    description: "Accent dot on chats where someone is typing.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.css('.chat-row[data-yy-typ]::after,.nav-item[data-yy-typ]::after{content:"";position:absolute;top:8px;right:8px;width:7px;height:7px;border-radius:50%;background:var(--accent);box-shadow:0 0 8px var(--accent)}');
      ctx.css('.chat-row,.nav-item{position:relative}');
      const tick = () => {
        const st = YM.Store.getState && YM.Store.getState();
        const typing = (st && st.typing) || {};
        document.querySelectorAll('.chat-row, .nav-item').forEach((row) => {
          const id = row.getAttribute('data-nav-chan') || row.getAttribute('data-channel-id') || row.dataset.channelId;
          const on = id && typing[id] && (Array.isArray(typing[id]) ? typing[id].length : Object.keys(typing[id] || {}).length);
          row.toggleAttribute('data-yy-typ', !!on);
        });
      };
      ctx.interval(tick, 1200);

    },
  });

  YM.definePlugin({
    name: "SendSpark",
    description: "Particle burst when you send a message.",
    authors: ['YapYur'],
    tags: ["Fun"],
    options: {},
    start(ctx) {

      const burst = (x, y) => {
        for (let i = 0; i < 12; i++) {
          const p = dom.h('div', { style: { position: 'fixed', left: x + 'px', top: y + 'px', width: '5px', height: '5px', borderRadius: '2px', background: ['var(--accent)','#f472b6','#fbbf24','#34d399','#60a5fa'][i % 5], zIndex: '2147483000', pointerEvents: 'none' } });
          document.body.appendChild(p);
          const ang = Math.random() * Math.PI * 2, dist = 36 + Math.random() * 50;
          p.animate([
            { transform: 'translate(0,0) scale(1)', opacity: 1 },
            { transform: 'translate(' + Math.cos(ang) * dist + 'px,' + Math.sin(ang) * dist + 'px) scale(0)', opacity: 0 },
          ], { duration: 650 + Math.random() * 300, easing: 'cubic-bezier(.2,.7,0,1)' }).onfinish = () => p.remove();
        }
      };
      const onKey = (e) => {
        if (e.key !== 'Enter' || e.shiftKey) return;
        const ta = e.target;
        if (!(ta instanceof HTMLTextAreaElement) || !ta.value.trim()) return;
        if (!(ta.closest('.composer') || ta.closest('[class*="composer"]'))) return;
        const r = ta.getBoundingClientRect();
        burst(r.right - 16, r.top);
      };
      document.addEventListener('keydown', onKey, true);
      ctx.cleanup(() => document.removeEventListener('keydown', onKey, true));

    },
  });

  YM.definePlugin({
    name: "CursorBuddy",
    description: "Soft orb that follows the cursor.",
    authors: ['YapYur'],
    tags: ["Fun"],
    options: {},
    start(ctx) {

      const orb = dom.h('div', { style: { position: 'fixed', left: '0', top: '0', width: '18px', height: '18px', borderRadius: '50%', zIndex: '2147483000', pointerEvents: 'none', background: 'radial-gradient(circle at 30% 30%, color-mix(in srgb,var(--accent) 80%,#fff), var(--accent))', boxShadow: '0 0 12px color-mix(in srgb,var(--accent) 50%,transparent)', opacity: '.7' } });
      let x = 20, y = 20, mx = 20, my = 20;
      const move = (e) => { mx = e.clientX; my = e.clientY; };
      document.addEventListener('mousemove', move, true);
      (document.body || document.documentElement).append(orb);
      ctx.interval(() => {
        x += (mx - x) * 0.18; y += (my - y) * 0.18;
        orb.style.transform = 'translate(' + Math.round(x - 9) + 'px,' + Math.round(y - 9) + 'px)';
      }, 16);
      ctx.cleanup(() => { document.removeEventListener('mousemove', move, true); orb.remove(); });

    },
  });

  YM.definePlugin({
    name: "TabReturnBar",
    description: "Accent bar when you return to the tab.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const bar = dom.h('div', { style: { position: 'fixed', top: '0', left: '0', right: '0', height: '3px', background: 'var(--accent)', zIndex: '2147483000', transform: 'scaleX(0)', transformOrigin: 'left', transition: 'transform .35s', pointerEvents: 'none' } });
      document.documentElement.appendChild(bar);
      const onVis = () => {
        if (document.visibilityState === 'visible') {
          bar.style.transform = 'scaleX(1)';
          setTimeout(() => { bar.style.transform = 'scaleX(0)'; }, 500);
        }
      };
      document.addEventListener('visibilitychange', onVis);
      ctx.cleanup(() => { document.removeEventListener('visibilitychange', onVis); bar.remove(); });

    },
  });

  YM.definePlugin({
    name: "ClockCorner",
    description: "Local clock in the bottom-left corner.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const el = dom.h('div', { style: { position: 'fixed', left: '10px', bottom: '10px', zIndex: '30', font: '11px ui-monospace,monospace', color: 'var(--text-faint)', pointerEvents: 'none', opacity: '.7' } });
      (document.body || document.documentElement).appendChild(el);
      const tick = () => { el.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }); };
      tick(); ctx.interval(tick, 1000); ctx.cleanup(() => el.remove());

    },
  });

  YM.definePlugin({
    name: "EscBlurComposer",
    description: "Escape blurs the composer.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      const onKey = (e) => {
        if (e.key !== 'Escape') return;
        const ta = document.activeElement;
        if (ta && ta.tagName === 'TEXTAREA') ta.blur();
      };
      document.addEventListener('keydown', onKey, true);
      ctx.cleanup(() => document.removeEventListener('keydown', onKey, true));

    },
  });

  YM.definePlugin({
    name: "TypeToFocusComposer",
    description: "Letter keys outside inputs focus the composer.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      const onKey = (e) => {
        if (e.ctrlKey || e.metaKey || e.altKey || e.key.length !== 1) return;
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
        const ta = document.querySelector('.composer textarea, textarea');
        if (ta) ta.focus();
      };
      document.addEventListener('keydown', onKey, true);
      ctx.cleanup(() => document.removeEventListener('keydown', onKey, true));

    },
  });

  YM.definePlugin({
    name: "UnloadGuard",
    description: "Warn before leave if composer has text.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      const onBefore = (e) => {
        const ta = document.querySelector('.composer textarea, textarea');
        if (ta && ta.value.trim()) { e.preventDefault(); e.returnValue = ''; }
      };
      window.addEventListener('beforeunload', onBefore);
      ctx.cleanup(() => window.removeEventListener('beforeunload', onBefore));

    },
  });

  YM.definePlugin({
    name: "CapsLockFlag",
    description: "Shows CAPS near the composer when Caps Lock is on.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.css('.yy-caps{font-size:10px;font-weight:700;color:var(--warning,#f59e0b);margin-left:8px}');
      const ensure = (on) => {
        const ta = document.querySelector('.composer textarea, textarea');
        if (!ta) return;
        let el = ta.parentElement && ta.parentElement.querySelector('.yy-caps');
        if (!on) { if (el) el.remove(); return; }
        if (!el) { el = dom.h('span', { class: 'yy-caps' }, 'CAPS'); (ta.parentElement || ta).appendChild(el); }
      };
      const onKey = (e) => { try { ensure(e.getModifierState && e.getModifierState('CapsLock')); } catch (_) {} };
      document.addEventListener('keydown', onKey, true);
      document.addEventListener('keyup', onKey, true);
      ctx.cleanup(() => { document.removeEventListener('keydown', onKey, true); document.removeEventListener('keyup', onKey, true); });

    },
  });

  YM.definePlugin({
    name: "PasteTrim",
    description: "Trims whitespace on paste into the composer.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      const onPaste = (e) => {
        const ta = e.target;
        if (!(ta instanceof HTMLTextAreaElement)) return;
        if (!(ta.closest('.composer') || ta.closest('[class*="composer"]'))) return;
        const text = e.clipboardData && e.clipboardData.getData('text/plain');
        if (text == null) return;
        const trimmed = text.trim();
        if (trimmed === text) return;
        e.preventDefault();
        const start = ta.selectionStart, end = ta.selectionEnd;
        const next = ta.value.slice(0, start) + trimmed + ta.value.slice(end);
        Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set.call(ta, next);
        ta.dispatchEvent(new Event('input', { bubbles: true }));
        ta.setSelectionRange(start + trimmed.length, start + trimmed.length);
      };
      document.addEventListener('paste', onPaste, true);
      ctx.cleanup(() => document.removeEventListener('paste', onPaste, true));

    },
  });

  YM.definePlugin({
    name: "LinkNewTab",
    description: "Open message links in a new tab.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.cleanup(YM.messages.decorate(({ el }) => {
        el.querySelectorAll('.msg-text a[href]').forEach((a) => { a.target = '_blank'; a.rel = 'noopener noreferrer'; });
      }));

    },
  });

  YM.definePlugin({
    name: "ScrollMemory",
    description: "Remembers scroll position per path in sessionStorage.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const key = () => 'yy-scroll:' + location.pathname + location.search;
      const save = util.debounce(() => {
        const sc = document.querySelector('.messages, .msg-list, [class*="message-list"]');
        if (sc) sessionStorage.setItem(key(), String(sc.scrollTop));
      }, 200);
      document.addEventListener('scroll', save, true);
      ctx.cleanup(() => document.removeEventListener('scroll', save, true));

    },
  });

  YM.definePlugin({
    name: "ServerTopOnDoubleClick",
    description: "Double-click rail to scroll channel list to top.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const onDbl = (e) => {
        if (!(e.target.closest && e.target.closest('.rail, .rail-item'))) return;
        const side = document.querySelector('.side, .sidebar, .channel-list');
        if (side) side.scrollTo({ top: 0, behavior: 'smooth' });
      };
      document.addEventListener('dblclick', onDbl, true);
      ctx.cleanup(() => document.removeEventListener('dblclick', onDbl, true));

    },
  });

  YM.definePlugin({
    name: "SidebarSearchFocus",
    description: "Press / to focus a search field.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const onKey = (e) => {
        if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) return;
        const t = e.target;
        if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
        const input = document.querySelector('input[type="search"], input[placeholder*="search" i]');
        if (!input) return;
        e.preventDefault();
        input.focus();
      };
      document.addEventListener('keydown', onKey, true);
      ctx.cleanup(() => document.removeEventListener('keydown', onKey, true));

    },
  });

  YM.definePlugin({
    name: "SelectAllMessage",
    description: "Triple-click selects message text only.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      const onClick = (e) => {
        if (e.detail !== 3) return;
        const text = e.target.closest && e.target.closest('.msg-text');
        if (!text) return;
        const range = document.createRange();
        range.selectNodeContents(text);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
      };
      document.addEventListener('click', onClick, true);
      ctx.cleanup(() => document.removeEventListener('click', onClick, true));

    },
  });

  YM.definePlugin({
    name: "NoDragImages",
    description: "Disable drag on chat images.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {
      ctx.css('.msg img,.embed-image{-webkit-user-drag:none;user-select:none}');
    },
  });

  YM.definePlugin({
    name: "GhostTypingLocal",
    description: "Local drafting label while the composer has text.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.css('.yy-draft{font-size:11px;color:var(--text-faint);margin-left:8px}');
      ctx.watch('textarea', (ta) => {
        if (!(ta.closest('.composer') || ta.closest('[class*="composer"]'))) return;
        const tick = () => {
          let el = ta.parentElement && ta.parentElement.querySelector('.yy-draft');
          if (!ta.value) { if (el) el.remove(); return; }
          if (!el) { el = dom.h('span', { class: 'yy-draft' }, 'drafting…'); (ta.parentElement || ta).appendChild(el); }
        };
        ta.addEventListener('input', tick); tick();
      });

    },
  });

  YM.definePlugin({
    name: "HideOwnName",
    description: "Hide author name on your own messages.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {

      ctx.cleanup(YM.messages.decorate(({ el, message }) => {
        const me = YM.Store.myId && YM.Store.myId();
        if (!me || !message || (message.author_id || message.authorId) !== me) return;
        const a = el.querySelector('.msg-author');
        if (a) a.style.display = 'none';
      }));

    },
  });

  YM.definePlugin({
    name: "RainbowAccentOnce",
    description: "Slowly cycles accent color (local).",
    authors: ['YapYur'],
    tags: ["Fun"],
    options: {},
    start(ctx) {

      let h = 0;
      const id = setInterval(() => {
        h = (h + 2) % 360;
        document.documentElement.style.setProperty('--accent', 'hsl(' + h + ' 80% 60%)');
        document.documentElement.style.setProperty('--accent-soft', 'hsl(' + h + ' 80% 60% / 0.2)');
      }, 120);
      ctx.cleanup(() => {
        clearInterval(id);
        document.documentElement.style.removeProperty('--accent');
        document.documentElement.style.removeProperty('--accent-soft');
      });

    },
  });

  YM.definePlugin({
    name: "ComposerMonoToggle",
    description: "Double-click composer chrome to toggle monospace.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      let mono = false;
      const onDbl = (e) => {
        const box = e.target.closest && e.target.closest('.composer, [class*="composer"]');
        if (!box) return;
        const ta = box.querySelector('textarea');
        if (!ta) return;
        mono = !mono;
        ta.style.fontFamily = mono ? 'ui-monospace, SFMono-Regular, Menlo, monospace' : '';
        YM.toast(mono ? 'Monospace on' : 'Monospace off', { duration: 1200 });
      };
      document.addEventListener('dblclick', onDbl, true);
      ctx.cleanup(() => document.removeEventListener('dblclick', onDbl, true));

    },
  });

  YM.definePlugin({
    name: "EscClosesPopovers",
    description: "Escape clicks a visible close/backdrop.",
    authors: ['YapYur'],
    tags: ["Utility"],
    options: {},
    start(ctx) {

      const onKey = (e) => {
        if (e.key !== 'Escape') return;
        const close = document.querySelector('.modal button[aria-label*="close" i], .overlay, .backdrop');
        if (close) close.click();
      };
      document.addEventListener('keydown', onKey, true);
      ctx.cleanup(() => document.removeEventListener('keydown', onKey, true));

    },
  });

  YM.definePlugin({
    name: "AltClickAvatarLog",
    description: "Alt-click avatar logs message id to console.",
    authors: ['YapYur'],
    tags: ["Developer"],
    options: {},
    start(ctx) {

      const onClick = (e) => {
        if (!e.altKey) return;
        const av = e.target.closest && e.target.closest('.avatar, img.avatar');
        if (!av) return;
        const row = av.closest(YM.messages.selector);
        if (row) console.log('%c[YapYur]', 'color:#7c3fff', 'message', row.getAttribute('data-message-id'));
      };
      document.addEventListener('click', onClick, true);
      ctx.cleanup(() => document.removeEventListener('click', onClick, true));

    },
  });

  YM.definePlugin({
    name: "ShiftEnterHint",
    description: "Tip under composer: Enter to send.",
    authors: ['YapYur'],
    tags: ["Chat"],
    options: {},
    start(ctx) {

      ctx.css('.composer{position:relative}.yy-seh{position:absolute;right:10px;bottom:4px;font-size:10px;color:var(--text-faint);pointer-events:none}');
      ctx.watch('.composer, [class*="composer"]', (box) => {
        if (box.querySelector('.yy-seh')) return;
        box.appendChild(dom.h('span', { class: 'yy-seh' }, 'Enter to send · Shift+Enter newline'));
      });

    },
  });


  YM.definePlugin({
    name: "PressyButtons",
    description: "Press scale on buttons.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".icon-btn,.btn,.send-btn{transition:transform .12s}.icon-btn:active,.btn:active,.send-btn:active{transform:scale(.93)}");
    },
  });

  YM.definePlugin({
    name: "AvatarHoverRing",
    description: "Accent ring on avatar hover.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".avatar{transition:box-shadow .15s,transform .15s}.avatar:hover{transform:scale(1.04);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 40%,transparent)}");
    },
  });

  YM.definePlugin({
    name: "MenuPopIn",
    description: "Pop-in animation for menus.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("@media (prefers-reduced-motion:no-preference){.ctx-menu,.modal,.emoji-picker{animation:yyPop .15s ease}@keyframes yyPop{from{opacity:0;transform:translateY(6px) scale(.98)}}");
    },
  });

  YM.definePlugin({
    name: "PrimaryGlow",
    description: "Glow under primary/send buttons.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".btn-primary,.send-btn,button[type=submit]{box-shadow:0 0 12px color-mix(in srgb,var(--accent) 42%,transparent)}");
    },
  });

  YM.definePlugin({
    name: "LargeChatAvatars",
    description: "Larger chat avatars.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg .avatar,.msg img.avatar{width:44px!important;height:44px!important;border-radius:50%}");
    },
  });

  YM.definePlugin({
    name: "SoftMediaCorners",
    description: "Rounder media corners.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg img,.embed-image,.msg video{border-radius:12px!important}");
    },
  });

  YM.definePlugin({
    name: "KeyboardFocus",
    description: "Strong focus-visible outline.",
    authors: ['YapYur'],
    tags: ["Accessibility"],
    options: {},
    start(ctx) {
      ctx.css(":focus-visible{outline:2px solid var(--accent)!important;outline-offset:2px}");
    },
  });

  YM.definePlugin({
    name: "HeavyAuthors",
    description: "Bolder author names.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-author{font-weight:700!important}");
    },
  });

  YM.definePlugin({
    name: "AlwaysUnderlineLinks",
    description: "Underline chat links.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-text a{text-decoration:underline;text-underline-offset:2px}");
    },
  });

  YM.definePlugin({
    name: "QuietTimestamps",
    description: "Dim timestamps.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-time,time.timestamp,.timestamp{opacity:.48}");
    },
  });

  YM.definePlugin({
    name: "ActiveChannelWash",
    description: "Accent wash on active channel.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".chat-row.active,.nav-item.active{background:var(--accent-soft)!important}");
    },
  });

  YM.definePlugin({
    name: "AccentTextCaret",
    description: "Accent caret in composer.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".composer textarea,textarea{caret-color:var(--accent)}");
    },
  });

  YM.definePlugin({
    name: "ActiveServerRing",
    description: "Glow on active server icon.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".rail-item.active{box-shadow:0 0 0 2px var(--accent),0 0 10px color-mix(in srgb,var(--accent) 35%,transparent)}");
    },
  });

  YM.definePlugin({
    name: "GroupBreathingRoom",
    description: "More space between groups.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg:not(.grouped){margin-top:12px!important}");
    },
  });

  YM.definePlugin({
    name: "SoftMessageHover",
    description: "Soft message hover.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg:hover{background:color-mix(in srgb,var(--bg-hover) 60%,transparent)!important}");
    },
  });

  YM.definePlugin({
    name: "CodeCardLook",
    description: "Card-like code blocks.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg pre,code{background:color-mix(in srgb,var(--bg-elev) 90%,#000)!important;border-radius:8px;border:1px solid var(--border)}");
    },
  });

  YM.definePlugin({
    name: "BiggerReactions",
    description: "Larger reactions.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".reaction,.msg-react,.react-btn{transform:scale(1.08)}");
    },
  });

  YM.definePlugin({
    name: "UnreadBreathe",
    description: "Pulse unread badges.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("@keyframes yyUb{50%{opacity:.5;transform:scale(.92)}}.unread-badge,.badge-unread,.rail-badge{animation:yyUb 1.7s ease-in-out infinite}");
    },
  });

  YM.definePlugin({
    name: "ComposerAir",
    description: "Composer padding.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".composer,.composer-box{padding:10px 12px!important}");
    },
  });

  YM.definePlugin({
    name: "StickyInputBar",
    description: "Sticky composer.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".composer{position:sticky;bottom:0;z-index:6;background:var(--bg-main)}");
    },
  });

  YM.definePlugin({
    name: "TightMemberList",
    description: "Dense member rows.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".people-row,.member-row,.member{padding-top:2px!important;padding-bottom:2px!important}");
    },
  });

  YM.definePlugin({
    name: "KillPromoChrome",
    description: "Hide promo/upsell chrome.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".promo-banner,.upsell,.help-nudge,[class*=\"upsell\"],[class*=\"promo\"]{display:none!important}");
    },
  });

  YM.definePlugin({
    name: "FrostPanels",
    description: "Frosted modals/menus.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".modal,.ctx-menu,.emoji-picker,.settings{backdrop-filter:blur(12px) saturate(1.15);background:color-mix(in srgb,var(--bg-elev) 80%,transparent)!important}");
    },
  });

  YM.definePlugin({
    name: "SlimSideRail",
    description: "Tighter sidebar rows.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".side .chat-row,.side .nav-item{padding:4px 8px!important;font-size:13px}");
    },
  });

  YM.definePlugin({
    name: "AccentScroll",
    description: "Accent scrollbars.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("*{scrollbar-width:thin;scrollbar-color:var(--accent) transparent}*::-webkit-scrollbar{width:8px}*::-webkit-scrollbar-thumb{background:color-mix(in srgb,var(--accent) 55%,#000);border-radius:8px}");
    },
  });

  YM.definePlugin({
    name: "NightImageDim",
    description: "Dim images at night.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg img,.embed-image{filter:brightness(.9) contrast(1.02)}");
    },
  });

  YM.definePlugin({
    name: "ZoomCursorOnMedia",
    description: "Zoom cursor on images.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg img,.embed-image{cursor:zoom-in}");
    },
  });

  YM.definePlugin({
    name: "RoleNameShimmer",
    description: "Shimmer on colored names.",
    authors: ['YapYur'],
    tags: ["Fun", "Appearance"],
    options: {},
    start(ctx) {
      ctx.css("@keyframes yySh{to{background-position:200% center}}.msg-author[style*=\"color\"]{background:linear-gradient(90deg,var(--accent),#f472b6,#38bdf8,var(--accent));background-size:200% auto;-webkit-background-clip:text;background-clip:text;color:transparent!important;animation:yySh 7s linear infinite}");
    },
  });

  YM.definePlugin({
    name: "ComposerBorderAccent",
    description: "Accent border when composer focused.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".composer:focus-within,.composer-box:focus-within{box-shadow:inset 0 0 0 1px var(--accent)}");
    },
  });

  YM.definePlugin({
    name: "MessageSepLine",
    description: "Hairline under message groups.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg:not(.grouped){border-top:1px solid color-mix(in srgb,var(--border) 70%,transparent)}");
    },
  });

  YM.definePlugin({
    name: "PillChannels",
    description: "Pill active channel.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".chat-row.active,.nav-item.active{border-radius:999px!important}");
    },
  });

  YM.definePlugin({
    name: "FlatButtons",
    description: "Flat bordered buttons.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".btn,.icon-btn{box-shadow:none!important;border:1px solid var(--border)}");
    },
  });

  YM.definePlugin({
    name: "DeepInput",
    description: "Deeper input backgrounds.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("input,textarea,.composer textarea{background:color-mix(in srgb,var(--bg-input) 90%,#000)!important}");
    },
  });

  YM.definePlugin({
    name: "TallComposer",
    description: "Taller composer min-height.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".composer textarea{min-height:72px!important}");
    },
  });

  YM.definePlugin({
    name: "SquareAvatars",
    description: "Squircle avatars.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".avatar,img.avatar{border-radius:10px!important}");
    },
  });

  YM.definePlugin({
    name: "MonoTimestamps",
    description: "Monospace timestamps.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-time,time,.timestamp{font-family:ui-monospace,Menlo,monospace;font-size:11px}");
    },
  });

  YM.definePlugin({
    name: "BrightAccentText",
    description: "Brighter link color.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-text a{color:color-mix(in srgb,var(--accent) 80%,#fff)!important}");
    },
  });

  YM.definePlugin({
    name: "HoverLiftCards",
    description: "Lift settings cards on hover.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".ym-card,.ym-theme-card{transition:transform .12s}.ym-card:hover,.ym-theme-card:hover{transform:translateY(-1px)}");
    },
  });

  YM.definePlugin({
    name: "HideOfflineDots",
    description: "Hide offline dots.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".status-dot.offline{display:none!important}");
    },
  });

  YM.definePlugin({
    name: "OnlineOnlyPulse",
    description: "Pulse online dots.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("@keyframes yyOn{50%{transform:scale(1.25);opacity:.7}}.status-dot.online{animation:yyOn 2s ease-in-out infinite}");
    },
  });

  YM.definePlugin({
    name: "ChatMaxWidth",
    description: "Cap chat width on ultrawide.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".messages,.msg-list{max-width:860px;margin-left:auto;margin-right:auto}");
    },
  });

  YM.definePlugin({
    name: "LetterSpaceNames",
    description: "Tracking on names.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-author{letter-spacing:.02em}");
    },
  });

  YM.definePlugin({
    name: "EmojiNudge",
    description: "Larger inline emoji.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-text img.emoji,.msg .emoji{width:1.35em!important;height:1.35em!important}");
    },
  });

  YM.definePlugin({
    name: "ReplyBarAccent",
    description: "Accent reply bar.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-reply,.reply-bar{border-left:3px solid var(--accent)!important;padding-left:8px}");
    },
  });

  YM.definePlugin({
    name: "EmbedFrame",
    description: "Framed embeds.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".embed,.msg-embed{border:1px solid var(--border);border-radius:10px;overflow:hidden}");
    },
  });

  YM.definePlugin({
    name: "SendBtnPill",
    description: "Pill send button.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".send-btn{border-radius:999px!important;padding-left:14px!important;padding-right:14px!important}");
    },
  });

  YM.definePlugin({
    name: "TopbarBlur",
    description: "Blurred top bar.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".topbar,.titlebar{backdrop-filter:blur(10px);background:color-mix(in srgb,var(--bg-main) 75%,transparent)!important}");
    },
  });

  YM.definePlugin({
    name: "CompactEmbeds",
    description: "Tighter embed padding.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".embed,.msg-embed{padding:6px 8px!important}");
    },
  });

  YM.definePlugin({
    name: "DimInactiveServers",
    description: "Dim inactive server icons.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".rail-item:not(.active){opacity:.55}.rail-item:not(.active):hover{opacity:1}");
    },
  });

  YM.definePlugin({
    name: "MessageAgeTint",
    description: "Slightly fade grouped messages.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg.grouped{opacity:.92}");
    },
  });

  YM.definePlugin({
    name: "BorderlessRail",
    description: "Borderless server rail.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".rail{border:none!important}");
    },
  });

  YM.definePlugin({
    name: "CardySettings",
    description: "Rounder settings shell.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".settings,.settings-main{border-radius:16px}");
    },
  });

  YM.definePlugin({
    name: "GaplessGroups",
    description: "Less padding in grouped msgs.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg.grouped{padding-top:0!important;padding-bottom:0!important}");
    },
  });

  YM.definePlugin({
    name: "WideComposer",
    description: "Full-width composer.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".composer,.composer-box{max-width:100%!important}");
    },
  });

  YM.definePlugin({
    name: "ThinTopGap",
    description: "Less gap under header.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".main-header,.channel-header{margin-bottom:4px!important}");
    },
  });

  YM.definePlugin({
    name: "AccentSelection",
    description: "Accent text selection.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("::selection{background:var(--accent-soft);color:var(--text)}");
    },
  });

  YM.definePlugin({
    name: "IconBtnRound",
    description: "Round icon buttons.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".icon-btn{border-radius:999px!important}");
    },
  });

  YM.definePlugin({
    name: "MessagePadX",
    description: "Extra horizontal message pad.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg{padding-left:12px!important;padding-right:12px!important}");
    },
  });

  YM.definePlugin({
    name: "EmbedShadow",
    description: "Shadow under embeds.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".embed,.msg-embed{box-shadow:0 4px 16px #0004}");
    },
  });

  YM.definePlugin({
    name: "FastEmoji",
    description: "No emoji picker animation.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".emoji-picker{animation:none!important}");
    },
  });

  YM.definePlugin({
    name: "SolidModals",
    description: "Opaque modals.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".modal{background:var(--bg-elev)!important;backdrop-filter:none!important}");
    },
  });

  YM.definePlugin({
    name: "ChatLineHeight",
    description: "Comfortable line-height.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-text{line-height:1.45!important}");
    },
  });

  YM.definePlugin({
    name: "NameCaps",
    description: "Small-caps author names.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-author{font-variant:small-caps;letter-spacing:.04em}");
    },
  });

  YM.definePlugin({
    name: "RailWide",
    description: "Wider server rail.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".rail{width:72px!important;min-width:72px!important}");
    },
  });

  YM.definePlugin({
    name: "SideWide",
    description: "Wider channel sidebar.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".side,.sidebar{min-width:260px!important}");
    },
  });

  YM.definePlugin({
    name: "NoUserSelectChrome",
    description: "Select message text only.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".rail,.side,.topbar{user-select:none}.msg-text{user-select:text}");
    },
  });

  YM.definePlugin({
    name: "QuietEmbedText",
    description: "Smaller embed text.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".embed,.msg-embed{font-size:13px}");
    },
  });

  YM.definePlugin({
    name: "SidebarStickyHeader",
    description: "Sticky sidebar categories.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".side .category,.sidebar .category{position:sticky;top:0;z-index:2;background:var(--bg-side)}");
    },
  });

  YM.definePlugin({
    name: "MessageActionAlways",
    description: "Actions always slightly visible.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg .msg-actions{opacity:.35}.msg:hover .msg-actions{opacity:1}");
    },
  });

  YM.definePlugin({
    name: "AccentHr",
    description: "Accent horizontal rules.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".msg-text hr{border:0;border-top:2px solid var(--accent);opacity:.5}");
    },
  });

  YM.definePlugin({
    name: "NoOutlineMouse",
    description: "No outline unless focus-visible.",
    authors: ['YapYur'],
    tags: ["Accessibility"],
    options: {},
    start(ctx) {
      ctx.css(":focus:not(:focus-visible){outline:none!important}");
    },
  });

  YM.definePlugin({
    name: "SmoothChannelSwitch",
    description: "Brief fade on message list.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("@media (prefers-reduced-motion:no-preference){.messages,.msg-list{animation:yyFade .12s ease}@keyframes yyFade{from{opacity:.6}}}");
    },
  });

  YM.definePlugin({
    name: "FocusRingPulse",
    description: "Pulse when focusing composer.",
    authors: ['YapYur'],
    tags: ["Accessibility"],
    options: {},
    start(ctx) {
      ctx.css("@keyframes yyFr{0%{box-shadow:0 0 0 0 var(--accent)}100%{box-shadow:0 0 0 6px transparent}}.composer textarea:focus{animation:yyFr .6s ease}");
    },
  });

  YM.definePlugin({
    name: "AttachChip",
    description: "Accent outline on attach control.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css("button[aria-label*=\"attach\" i],button[title*=\"upload\" i],.attach-btn{box-shadow:0 0 0 1px var(--accent)}");
    },
  });

  YM.definePlugin({
    name: "LowerSidebarContrast",
    description: "Quieter sidebar text.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".side,.sidebar{color:var(--text-muted)}");
    },
  });

  YM.definePlugin({
    name: "SoftDanger",
    description: "Softer danger buttons.",
    authors: ['YapYur'],
    tags: ["Appearance"],
    options: {},
    start(ctx) {
      ctx.css(".danger,.btn-danger{background:color-mix(in srgb,var(--danger) 85%,#000)!important}");
    },
  });



  // ---- YapYur requested extras ----
  const YY_IDS = { owner: '20bd1019-0970-4793-8664-94f0e3b2d361', moderator: '424bed31-dcb7-46eb-886f-ebd4acdbbc79' };
  dom.css.set('yy-requested-badges', `
    .yy-role-badge{display:inline-flex!important;align-items:center;justify-content:center;margin-left:5px;padding:2px 5px;border-radius:5px;font:700 10px/1.3 system-ui;vertical-align:middle;white-space:nowrap;position:relative;z-index:2}
    .yy-owner-badge{background:#f5c542;color:#332400}.yy-mod-badge{background:#4388ff;color:#fff}.yy-platform-badge{background:#7c3fff;color:#fff}
    .yy-read-all{display:flex!important;box-sizing:border-box!important;width:76px!important;min-width:76px!important;max-width:76px!important;height:38px!important;min-height:38px!important;margin:6px auto 12px!important;padding:3px 5px!important;align-items:center!important;justify-content:center!important;text-align:center!important;line-height:1.1!important;border:1px solid var(--border,#444)!important;border-radius:12px!important;background:var(--bg-elev,#222)!important;color:var(--text,#eee)!important;font:600 12px/1.1 system-ui,sans-serif!important;white-space:normal!important;overflow-wrap:normal!important;word-break:keep-all!important;cursor:pointer!important;position:relative!important;z-index:2!important;flex:0 0 38px!important}

.yy-read-all-wrap~*{position:relative!important}
  `);
  function yyUserId(el) {
    const uuid=/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
    const strongKeys=['data-user-id','data-userid','data-author-id','data-account-id','data-profile-id','data-member-id','data-uid'];
    // Prefer explicit user identity attributes over generic data-id (often a message or component ID).
    for (let n=el,depth=0; n && n!==document.documentElement && depth<6; n=n.parentElement,depth++) {
      for (const k of strongKeys) {
        const v=n.getAttribute && n.getAttribute(k);
        if(v){const m=v.match(uuid);if(m)return m[0].toLowerCase();}
      }
      for (const a of (n.attributes ? [...n.attributes] : [])) {
        if(!/user|author|account|profile|member|props|state/i.test(a.name)) continue;
        const m=(a.value||'').match(uuid); if(m)return m[0].toLowerCase();
      }
      const links=n.querySelectorAll ? n.querySelectorAll('a[href]') : [];
      for(const link of links) {
        const href=link.getAttribute('href')||'';
        if(/user|profile|member|account/i.test(href)){const m=href.match(uuid);if(m)return m[0].toLowerCase();}
      }
    }
    // Last resort: generic data-id only on the element itself.
    const generic=el.getAttribute && el.getAttribute('data-id');
    if(generic){const m=generic.match(uuid);if(m)return m[0].toLowerCase();}
    return '';
  }
  async function yyReadAll() {
    // Resolve the live actions module (may need a short wait after page load).
    let live = null;
    for (let i = 0; i < 20; i++) {
      live = (YM.live && YM.live()) || null;
      if (live && typeof live.markRead === 'function') break;
      // Direct finder fallbacks in case live() cache is stale
      try {
        live = YM.finder.findExports(['markRead', 'sendMessage'])
          || YM.finder.findExports(['markRead', 'markServerRead'])
          || YM.finder.findExports(['markRead']);
      } catch (_) { live = null; }
      if (live && typeof live.markRead === 'function') break;
      await new Promise((r) => setTimeout(r, 150));
    }

    const st = YM.Store && YM.Store.getState && YM.Store.getState();
    if (!live || typeof live.markRead !== 'function') {
      YM.toast('Could not reach Yapper markRead. Reload the page and try again.', { type: 'info' });
      return;
    }
    if (!st) {
      YM.toast('Yapper store not ready yet — wait a second and try again.', { type: 'info' });
      return;
    }

    const unread = st.unread || {};
    const mentions = st.mentions || {};
    const channels = st.channels || {};
    const ids = new Set();

    for (const [id, n] of Object.entries(unread)) {
      if ((typeof n === 'number' ? n > 0 : !!n) && id) ids.add(String(id));
    }
    for (const [id, n] of Object.entries(mentions)) {
      if ((typeof n === 'number' ? n > 0 : !!n) && id) ids.add(String(id));
    }
    for (const [id, ch] of Object.entries(channels)) {
      if (!ch || typeof ch !== 'object') continue;
      const u = ch.unread ?? ch.unread_count ?? ch.unreadCount;
      const m = ch.mentions ?? ch.mention_count ?? ch.mentionCount;
      if ((typeof u === 'number' ? u > 0 : !!u) || (typeof m === 'number' ? m > 0 : !!m)) ids.add(String(id));
    }

    if (!ids.size) {
      YM.toast('Nothing unread.', { type: 'info' });
      return;
    }

    let count = 0;
    // markServerRead clears every unread channel in a server in one go
    if (typeof live.markServerRead === 'function') {
      const servers = new Set();
      for (const id of ids) {
        const ch = channels[id];
        if (ch && ch.server_id) servers.add(ch.server_id);
      }
      for (const sid of servers) {
        try { live.markServerRead(sid); } catch (_) {}
      }
    }

    for (const id of ids) {
      try {
        await live.markRead(id);
        count++;
      } catch (_) {
        try { live.markRead(id); count++; } catch (__) {}
      }
    }

    if (typeof live.flushReads === 'function') {
      try { live.flushReads(); } catch (_) {}
    }

    // Ensure local badges clear immediately
    if (ids.size && YM.Store.setState) {
      try {
        YM.Store.setState((s) => {
          if (!s) return s;
          const nextUnread = { ...(s.unread || {}) };
          const nextMentions = { ...(s.mentions || {}) };
          for (const id of ids) {
            delete nextUnread[id];
            delete nextMentions[id];
          }
          return { unread: nextUnread, mentions: nextMentions };
        });
      } catch (_) {}
    }

    YM.toast('Marked ' + count + ' channel(s) as read.', { type: 'success' });
  }
  function yyAddReadAll() {
    if (document.querySelector('.yy-read-all')) return;
    const controls=[...document.querySelectorAll('button,[role="button"],a,[aria-label],[title]')];
    const settings=controls.find(el=>/settings|preferences/i.test((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.innerText||el.textContent||'')));
    if(!settings) return;
    const b=document.createElement('button'); b.type='button'; b.className='yy-read-all'; b.textContent='Read All Pings';
    b.title='Mark available pings as read'; b.setAttribute('aria-label','Read All Pings');
    b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();yyReadAll();});
    b.setAttribute('data-yapyur-control','read-all');
    // Put it beside the settings button (the small R/settings control), without moving folder nodes.
    settings.insertAdjacentElement('afterend',b);
  }
  function yyBadges() {
    const names=document.querySelectorAll('[class*="username" i],[class*="display-name" i],[class*="user-name" i],[class*="author" i],.msg-author,[data-user-id],[data-userid],[data-author-id],[data-account-id],[data-profile-id],a[href*="/users/" i],a[href*="/user/" i],a[href*="/profile/" i],a[href*="/members/" i]');
    for(const el of names) {
      if(!el || el.closest('.yy-read-all') || el.classList.contains('yy-role-badge')) continue;
      const id=yyUserId(el);
      if(!id) continue;
      const owner=id===YY_IDS.owner, mod=id===YY_IDS.moderator;
      if(!owner && !mod) continue;
      const target=el.closest('.msg-author,[class*="username" i],[class*="display-name" i],[class*="user-name" i]') || el;
      if(target.querySelectorAll) target.querySelectorAll('.yy-role-badge').forEach(b=>b.remove());
      const b=document.createElement('span');
      b.className='yy-role-badge '+(owner?'yy-owner-badge':'yy-mod-badge');
      b.textContent=owner?'♛ OWNER':'◆ MOD';
      b.title=owner?'YapYur owner':'YapYur moderator';
      target.appendChild(b);
    }
  }
  let yyQueued=false;
  const yyObserver=new MutationObserver(()=>{if(yyQueued)return;yyQueued=true;requestAnimationFrame(()=>{yyQueued=false;yyAddReadAll();yyBadges();});});
  function yyInit(){yyAddReadAll();yyBadges();yyObserver.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['data-user-id','data-userid','data-author-id','data-id','data-account-id','data-profile-id','data-member-id']});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',yyInit,{once:true});else yyInit();

  YM.definePlugin({
    name: 'PetPet',
    description: 'Adds a /petpet shortcut to the message composer.',
    authors: ['YapYur'],
    tags: ['Fun', 'Composer'],
    options: {},
    start(ctx) {
      const addShortcut = () => {
        const input = document.querySelector('.composer textarea,.composer input,[contenteditable="true"]');
        if (!input || input.dataset.yyPetpetBound) return;
        input.dataset.yyPetpetBound = '1';
        input.addEventListener('keydown', e => {
          if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
          const value = input.isContentEditable ? input.textContent : input.value;
          if (!/^\/petpet(?:\s|$)/i.test(value || '')) return;
          e.preventDefault();
          const replacement = (value || '').replace(/^\/petpet\s*/i, '');
          if (input.isContentEditable) { input.textContent = replacement; input.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:replacement})); }
          else { input.value = replacement; input.dispatchEvent(new Event('input',{bubbles:true})); }
          YM.toast('PetPet shortcut recognized. Add a GIF/image after the command to send it.', {type:'info'});
        });
      };
      addShortcut();
      const mo = new MutationObserver(addShortcut); mo.observe(document.documentElement,{childList:true,subtree:true});
      ctx.onStop(() => mo.disconnect());
    }
  });

  // ---- Settings UI in Yapper gear: Plugins with All / On / Off ----
  const h = dom.h;
  const Ui = (YM.settingsUi = {});

  function pagePlugins(panel) {
    let filter = 'all', query = '', tag = '';
    const summary = h('span', { class: 'ym-summary' });
    const list = h('div', { class: 'ym-grid' });
    const chips = h('div', { class: 'ym-chips' });
    const segBtns = [['all', 'All'], ['on', 'On'], ['off', 'Off']].map(([v, label]) =>
      h('button', { type: 'button', class: 'ym-seg-btn', 'data-v': v, onClick: () => { filter = v; draw(); } }, label));
    const seg = h('div', { class: 'ym-seg', role: 'group', 'aria-label': 'Show' }, ...segBtns);
    const search = h('input', { class: 'ym-input ym-search', type: 'search', placeholder: 'Search plugins…', onInput: (e) => { query = e.target.value; draw(); } });

    function draw() {
      segBtns.forEach((b) => b.classList.toggle('on', b.dataset.v === filter));
      list.replaceChildren();
      const q = query.trim().toLowerCase();
      const all = YM.plugins.list().slice().sort((a, b) => a.name.localeCompare(b.name, 'en'));
      const items = all.filter((p) => {
        const on = YM.plugins.isEnabled(p.name);
        if (filter === 'on' && !on) return false;
        if (filter === 'off' && on) return false;
        if (tag && !(p.tags || []).includes(tag)) return false;
        return !q || (p.name + ' ' + (p.description || '') + ' ' + (p.tags || []).join(' ')).toLowerCase().includes(q);
      });
      summary.textContent = items.length + ' of ' + all.length;
      const counts = new Map();
      for (const p of all) for (const t of p.tags || []) counts.set(t, (counts.get(t) || 0) + 1);
      chips.replaceChildren(...[...counts.entries()].sort((a, b) => b[1] - a[1]).map(([t, n]) =>
        h('button', { type: 'button', class: 'ym-chip-btn' + (tag === t ? ' on' : ''), onClick: () => { tag = tag === t ? '' : t; draw(); } }, t, h('em', {}, String(n)))));
      for (const p of items) {
        const on = YM.plugins.isEnabled(p.name);
        const running = YM.plugins.isRunning(p.name);
        list.append(h('div', { class: 'ym-card' + (on ? ' on' : '') },
          h('div', { class: 'ym-card-top' },
            h('div', { class: 'ym-card-title' }, h('b', {}, p.name), h('span', { class: 'ym-tags' }, (p.tags || []).join(' · ') + (running ? ' · running' : ''))),
            h('input', { type: 'checkbox', class: 'yy-switch', checked: on, onChange: (e) => {
              YM.plugins.setEnabled(p.name, e.target.checked);
              YM.toast((e.target.checked ? 'Enabled ' : 'Disabled ') + p.name, { type: 'success', duration: 2000 });
              draw();
            }})),
          h('div', { class: 'ym-card-desc' }, p.description || ''),
          h('div', { class: 'ym-hint' }, (p.authors || []).join(', '))));
      }
      if (!items.length) list.append(h('div', { class: 'ym-empty' }, 'No plugins match this filter.'));
    }

    panel.append(
      h('div', { class: 'ym-page-head' }, h('h2', {}, 'Plugins'), summary),
      h('p', { class: 'ym-hint' }, 'Nothing is on by default. Use All / On / Off to filter, then toggle what you want — plugins start immediately.'),
      h('div', { class: 'ym-toolbar' }, search, seg),
      chips, list,
    );
    draw();
  }

  function pageThemes(panel) {
    const fileInput = h('input', {
      type: 'file', accept: '.css,.theme.css,text/css', multiple: true, style: { display: 'none' },
      onChange: async (e) => {
        const files = [...(e.target.files || [])];
        e.target.value = '';
        if (!files.length) return;
        let n = 0;
        for (const f of files) {
          try {
            const text = await f.text();
            Themes.importFromText(text, f.name);
            n++;
          } catch (err) {
            YM.log.error('theme import', err);
            YM.toast('Failed: ' + f.name, { type: 'error' });
          }
        }
        if (n) YM.toast('Imported ' + n + ' theme' + (n === 1 ? '' : 's'), { type: 'success' });
        panel.replaceChildren();
        pageThemes(panel);
      },
    });

    panel.append(
      h('h2', {}, 'Themes'),
      h('p', { class: 'ym-hint' }, 'Bundled themes by Tvman plus any you import. Multiple can be enabled.'),
      h('div', { class: 'ym-toolbar', style: { marginBottom: '14px' } },
        h('button', {
          type: 'button', class: 'ym-btn ym-btn-primary',
          onClick: () => fileInput.click(),
        }, 'Import theme file…'),
        h('span', { class: 'ym-hint' }, 'Accepts .css / .theme.css'),
        fileInput,
      ),
    );

    const enabled = new Set(YM.settings.get('enabledThemes', []) || []);
    for (const t of Themes.list()) {
      const on = enabled.has(t.fileName);
      const isCustom = !!(t.custom || String(t.fileName).startsWith('custom:'));
      panel.append(h('div', { class: 'ym-theme-card' },
        h('div', {},
          h('b', {}, t.name),
          isCustom ? h('span', { class: 'ym-tags' }, ' · imported') : null,
          h('div', { class: 'ym-hint' }, t.description || ''),
          h('div', { class: 'ym-hint' }, (t.author || '') + (t.fileName ? ' · ' + String(t.fileName).replace(/^custom:/, '') : '')),
        ),
        h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } },
          isCustom ? h('button', {
            type: 'button', class: 'ym-btn',
            onClick: () => {
              Themes.removeCustom(t.fileName);
              YM.toast('Removed ' + t.name);
              panel.replaceChildren();
              pageThemes(panel);
            },
          }, 'Remove') : null,
          h('button', {
            class: 'ym-btn' + (on ? ' ym-btn-primary' : ''), type: 'button',
            onClick: () => {
              Themes.toggle(t.fileName, !on);
              panel.replaceChildren();
              pageThemes(panel);
            },
          }, on ? 'Enabled' : 'Enable'),
        ),
      ));
    }
  }

  function pageCss(panel) {
    const ta = h('textarea', { class: 'ym-input ym-code', rows: 14, placeholder: '/* Custom CSS */' });
    ta.value = QuickCss.get();
    panel.append(h('h2', {}, 'Custom CSS'), ta,
      h('button', { class: 'ym-btn ym-btn-primary', type: 'button', style: { marginTop: '8px' }, onClick: () => { QuickCss.set(ta.value); YM.toast('Saved', { type: 'success' }); } }, 'Save'));
  }

  function pageAbout(panel) {
    panel.append(
      h('h2', {}, 'About YapYur'),
      h('p', {}, 'Package: ' + YM.packageId),
      h('p', {}, 'Version: ' + YM.version),
      h('p', {}, 'Plugins registered: ' + YM.plugins.list().length),
      h('p', {}, 'Running now: ' + [...running.keys()].join(', ') || 'none'),
      h('p', { class: 'ym-hint' }, 'Open Yapper’s gear → YapYur. MessageLogger & BetterFolders are the YapCord ports — enable them under Plugins.'),
    );
  }

  const RENDER = { plugins: pagePlugins, themes: pageThemes, css: pageCss, about: pageAbout };

  function activate(page) {
    const s = document.querySelector('.settings');
    const main = s && (s.querySelector('.settings-main') || s.querySelector('.settings-body') || s);
    if (!s || !main || !RENDER[page]) return;
    s.querySelectorAll('.ym-panel').forEach((p) => p.remove());
    s.classList.add('ym-active');
    s.querySelectorAll('.ym-nav-btn').forEach((b) => b.classList.toggle('active', b.dataset.ymPage === page));
    const panel = h('div', { class: 'ym-panel' });
    main.append(panel);
    try { RENDER[page](panel); } catch (e) { YM.log.error(e); panel.append(h('div', {}, String(e && e.message))); }
  }

  function injectNav(nav) {
    if (nav.querySelector('.ym-nav-label')) return;
    nav.append(h('div', { class: 'settings-nav-label ym-nav-label', style: { marginTop: '14px' } }, 'YapYur'));
    for (const p of [{ id: 'plugins', label: 'Plugins' }, { id: 'themes', label: 'Themes' }, { id: 'css', label: 'Custom CSS' }, { id: 'about', label: 'About' }]) {
      nav.append(h('button', { class: 'ym-nav-btn', type: 'button', dataset: { ymPage: p.id }, onClick: () => activate(p.id) }, p.label));
    }
    nav.addEventListener('click', (e) => {
      const b = e.target instanceof Element ? e.target.closest('button') : null;
      if (b && !b.classList.contains('ym-nav-btn')) {
        const s = document.querySelector('.settings');
        if (s) { s.classList.remove('ym-active'); s.querySelectorAll('.ym-panel').forEach((x) => x.remove()); }
      }
    }, true);
  }
  dom.watch('.settings-nav', injectNav);

  dom.css.set('core-ui', `
.yy-toasts{position:fixed;right:16px;bottom:16px;z-index:2147483000;display:flex;flex-direction:column;gap:8px;pointer-events:none}
.yy-toast{pointer-events:auto;padding:10px 14px;border-radius:10px;background:var(--bg-elev,#222);color:var(--text,#eee);border:1px solid var(--border);font:13px system-ui;max-width:320px}
.yy-toast.out{opacity:0;transition:.2s}
.ym-nav-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-faint);padding:4px 10px}
.ym-nav-btn{display:block;width:100%;text-align:left;padding:8px 12px;border:0;background:transparent;color:var(--text-muted);border-radius:8px;cursor:pointer;font:13px system-ui}
.ym-nav-btn:hover{background:var(--bg-hover);color:var(--text)}.ym-nav-btn.active{background:var(--accent-soft);color:var(--accent);font-weight:600}
.ym-panel{padding:8px 4px 24px}.ym-page-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin-bottom:10px}
.ym-page-head h2{margin:0;font-size:22px}.ym-summary{color:var(--text-muted);font-size:13px}
.ym-toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:12px}.ym-search{flex:1;min-width:140px}
.ym-seg{display:inline-flex;padding:3px;border-radius:10px;background:var(--bg-input);border:1px solid var(--border)}
.ym-seg-btn{padding:5px 14px;border-radius:7px;font-size:13px;font-weight:600;color:var(--text-muted);cursor:pointer;background:transparent;border:0}
.ym-seg-btn.on{background:var(--accent);color:var(--on-accent,#fff)}
.ym-chips{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 12px}
.ym-chip-btn{display:inline-flex;gap:6px;padding:4px 10px;border-radius:999px;font-size:12px;font-weight:600;border:1px solid var(--border);background:var(--bg-elev);color:var(--text-muted);cursor:pointer}
.ym-chip-btn em{font-style:normal;opacity:.7}.ym-chip-btn.on{border-color:var(--accent);color:var(--accent)}
.ym-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px}
.ym-card{border:1px solid var(--border);border-radius:12px;background:var(--bg-elev);padding:12px;display:flex;flex-direction:column;gap:6px}
.ym-card.on{border-color:color-mix(in srgb,var(--accent) 45%,var(--border))}
.ym-card-top{display:flex;justify-content:space-between;align-items:center;gap:10px}
.ym-card-title{display:flex;flex-direction:column;gap:2px}.ym-tags{font-size:11px;color:var(--text-faint)}
.ym-card-desc{color:var(--text-muted);font-size:13px;line-height:1.4}
.ym-empty{padding:18px;text-align:center;color:var(--text-muted)}.ym-hint{font-size:12px;color:var(--text-faint)}
.ym-input{padding:6px 10px;border-radius:8px;border:1px solid var(--border);background:var(--bg-input);color:var(--text);font:13px system-ui}
.ym-code{width:100%;font:12px monospace;min-height:160px}
.ym-btn{padding:6px 12px;border-radius:8px;border:1px solid var(--border);background:var(--bg-hover);color:var(--text);cursor:pointer;font:12px system-ui}
.ym-btn-primary{background:var(--accent);border-color:transparent;color:#fff}
.ym-theme-card{padding:10px;border:1px solid var(--border);border-radius:10px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;gap:10px}
.yy-switch{appearance:none;width:40px;height:22px;border-radius:11px;background:#555;position:relative;cursor:pointer;flex-shrink:0}
.yy-switch:checked{background:var(--accent,#7c3fff)}
.yy-switch::after{content:"";position:absolute;top:2px;left:2px;width:18px;height:18px;border-radius:50%;background:#fff;transition:.15s}
.yy-switch:checked::after{left:20px}
.settings.ym-active .settings-main > :not(.ym-panel){display:none}
`);

  // boot
  Themes.applyEnabled();
  QuickCss.apply();
  // Only start plugins the user previously enabled (none on first run)
  YM.plugins.startEnabled();
  YM.log.info('YapYur ready', { plugins: YM.plugins.list().length, enabled: YM.plugins.list().filter((p) => YM.plugins.isEnabled(p.name)).map((p) => p.name) });
})();
//# sourceURL=yapyur://bundle.js
