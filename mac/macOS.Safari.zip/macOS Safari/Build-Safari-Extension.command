#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
SOURCE="$HERE/YapYur Safari Web Extension Source"
OUT="$HERE/YapYur-Safari-Xcode"
if ! xcode-select -p >/dev/null 2>&1; then
  echo "Install Xcode from the Mac App Store, open it once, and accept its license first." >&2; exit 1
fi
if ! xcrun --find safari-web-extension-converter >/dev/null 2>&1; then
  echo "Safari Web Extension Converter not found. Install/upgrade Xcode and its command line tools." >&2; exit 1
fi
if [ -e "$OUT" ]; then echo "Output already exists: $OUT (move/delete it before retrying)." >&2; exit 1; fi
xcrun safari-web-extension-converter "$SOURCE" --project-location "$OUT" --app-name YapYur --bundle-identifier com.tvmanknown.yapyur --swift
echo
echo "Project created at: $OUT"
echo "Open the .xcodeproj, choose your Apple development team under Signing & Capabilities, then Run to install on this Mac."
