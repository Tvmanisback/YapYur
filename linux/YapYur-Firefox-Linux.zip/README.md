# Linux support (not Chrome-only)

YapYur is packaged as a Firefox WebExtension for Firefox and Firefox-based browsers such as LibreWolf and Waterfox.

## Install for testing
1. Open `about:debugging#/runtime/this-firefox` in Firefox.
2. Click **Load Temporary Add-on…** and choose `manifest.json` from this folder.
3. Visit `https://yapper.website/` or `https://yapin.gg/`.

Temporary add-ons are removed when Firefox closes. For a persistent install, the extension must be signed by Mozilla and distributed as an approved add-on/XPI. LibreWolf/Waterfox may have different signing policies.

This does not require Chrome or Chromium. The same source can be loaded in compatible Firefox-family browsers.
